"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Users = void 0;
class Users {
    constructor(Id = 0, Name = "", eMail = "") {
        this.Id = Id;
        this.Name = Name;
        this.eMail = eMail;
    }
}
exports.Users = Users;
