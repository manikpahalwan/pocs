"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = __importDefault(require("http")); //importing http 
const express_1 = __importDefault(require("express")); //importing express
const body_parser_1 = __importDefault(require("body-parser"));
const users_1 = require("./users");
//creating dummy database
let users = [
    new users_1.Users(1, "MANIK", "mp@gmail.com"),
    new users_1.Users(2, "SAGAR", "sj@gmail.com"),
    new users_1.Users(3, "SURAJ", "sm@gmail.com"),
    new users_1.Users(4, "SANDEEP", "ss@gmail.com"),
    new users_1.Users(5, "PRADYUMN", "py@gmail.com"),
];
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken")); //importing express
///creating secret key
const secretKey = "secretKey";
//declaring port
const port = 9999;
//creating express app
const expressapp = (0, express_1.default)();
//parsing the body into json format
expressapp.use(body_parser_1.default.json());
//Adding a new User
expressapp.post("/addUser", AddUser);
//real all users
expressapp.get("/users", GetAllUsers); //handles request to get all vehicles
//Authenticating the user (user logging in )
expressapp.get("/login/:id", logIn);
//Updating the user
//user getting information
expressapp.post("/update", verifyToken, (req, res) => {
    jsonwebtoken_1.default.verify(req.params.token, secretKey, (err, authData) => {
        if (err)
            res.status(404).send("INVALID TOKEN");
        else {
            console.log(typeof (authData));
            // console.log(authData!.authData!.user[0]!.Id!)
            // authData=JSON.parse(authData)
            res.status(400).send(authData);
            // json({
            //     authData
            // //   Id:authData.authData.user[0].Id
            // })
        }
    });
    // const decode:jwt.JwtPayload|string=jwt.verify(req.params.token, secretKey);
    // res.json({
    //     login: true,
    //     data: decode
    // });
});
//Deleting the user
expressapp.post("/delete", verifyToken, (req, res) => {
    jsonwebtoken_1.default.verify(req.params.token, secretKey, (err, authData) => {
        if (err)
            res.status(404).send("INVALID TOKEN");
        else {
            // authData=JSON.parse(authData?);
            console.log(typeof (authData));
            // console.log(authData!.authData!.user[0]!.Id!)
            // authData=JSON.parse(authData)
            res.status(400).send(authData);
            // json({
            //     authData
            // //   Id:authData.authData.user[0].Id
            // })
        }
    });
    // const decode:jwt.JwtPayload|string=jwt.verify(req.params.token, secretKey);
    // res.json({
    //     login: true,
    //     data: decode
    // });
});
function verifyToken(req, res, next) {
    const bearerHeader = req.headers['authorization'];
    if (typeof bearerHeader !== 'undefined') {
        const bearer = bearerHeader.split(" ");
        const token = bearer[1];
        req.params.token = token;
        next();
    }
    else {
        res.status(404).send({
            result: "Token is Not Valid"
        });
    }
}
//ADDING USER
function AddUser(req, res) {
    let newuser = req.body;
    console.log(newuser);
    users.push(newuser);
    res.status(201).send("New User Added");
}
//READING ALL USERs
function GetAllUsers(req, res) {
    res.status(200).json(users); //.json retuns a json object
}
function logIn(req, res) {
    let Uid = parseInt(req.params.id);
    const user = users.filter(u => u.Id === Uid);
    //creating token
    jsonwebtoken_1.default.sign({ user }, "secretKey", { expiresIn: '300s' }, (err, token) => {
        res.status(400).json({
            token
        });
    });
}
const server = http_1.default.createServer(expressapp);
server.listen(port);
let aaa = {
    "user": [
        {
            "Id": 2,
            "Name": "SAGAR",
            "eMail": "sj@gmail.com"
        }
    ],
    "iat": 1671522037,
    "exp": 1671522337
};
