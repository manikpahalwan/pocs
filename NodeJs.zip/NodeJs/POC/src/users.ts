export class Users{

    constructor(
        public Id:number=0,
        public Name:string="",
        public eMail:string=""
    ){}
}