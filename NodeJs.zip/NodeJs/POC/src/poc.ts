import http from 'http' //importing http 
import express from 'express'   //importing express
import bodyParser from 'body-parser';
import { Users } from './users';

//creating dummy database
let  users:Users[]=[
    new Users(1,"MANIK","mp@gmail.com"),
    new Users(2,"SAGAR","sj@gmail.com"),
    new Users(3,"SURAJ","sm@gmail.com"),
    new Users(4,"SANDEEP","ss@gmail.com"),
    new Users(5,"PRADYUMN","py@gmail.com"),
];

import jwt from 'jsonwebtoken'   //importing express
import { appendFile } from 'fs';
import { json } from 'stream/consumers';

///creating secret key
const secretKey:string="secretKey"

//declaring port
const port=9999;

//creating express app
const expressapp:express.Express=express();

//parsing the body into json format
expressapp.use(bodyParser.json());

//Adding a new User
expressapp.post("/addUser",AddUser)

//real all users
expressapp.get("/users",GetAllUsers)  //handles request to get all vehicles

//Authenticating the user (user logging in )
expressapp.get("/login/:id",logIn)

//Updating the user
//user getting information
expressapp.post("/update",verifyToken,(req:express.Request,res:express.Response)=>{

    jwt.verify(req.params.token,secretKey,(err,authData: string | jwt.JwtPayload | undefined)=>{
        if(err) res.status(404).send("INVALID TOKEN")
        else{
            console.log(typeof(authData))
            // console.log(authData!.authData!.user[0]!.Id!)
            // authData=JSON.parse(authData)
            res.status(400).send(authData)
            // json({
            //     authData
            // //   Id:authData.authData.user[0].Id
            // })
        }
    })
    
    // const decode:jwt.JwtPayload|string=jwt.verify(req.params.token, secretKey);
   
    // res.json({
    //     login: true,
    //     data: decode
    // });
})



//Deleting the user
expressapp.post("/delete",verifyToken,(req:express.Request,res:express.Response)=>{

    jwt.verify(req.params.token,secretKey,(err,authData: string | jwt.JwtPayload | undefined)=>{
        if(err) res.status(404).send("INVALID TOKEN")
        else{
            // authData=JSON.parse(authData?);
            console.log(typeof(authData))
            // console.log(authData!.authData!.user[0]!.Id!)
            // authData=JSON.parse(authData)
            res.status(400).send(authData)
            // json({
            //     authData
            // //   Id:authData.authData.user[0].Id
            // })
        }
    })
    
    // const decode:jwt.JwtPayload|string=jwt.verify(req.params.token, secretKey);
   
    // res.json({
    //     login: true,
    //     data: decode
    // });
})



    
function verifyToken(req:express.Request,res:express.Response,next:any){
const bearerHeader=req.headers['authorization'];
if(typeof bearerHeader !=='undefined'){
    const bearer=bearerHeader.split(" ")
    const token =bearer[1];
    req.params.token=token
    next();
}
else{
    res.status(404).send({
        result:"Token is Not Valid"
    })
}

}

//ADDING USER
function AddUser(req:express.Request,res:express.Response)
{
    let newuser:Users=req.body;
    console.log(newuser);
    users.push(newuser);
    res.status(201).send("New User Added")
}


//READING ALL USERs
function GetAllUsers(req:express.Request,res:express.Response)
{
    res.status(200).json(users)      //.json retuns a json object
}


function logIn(req:express.Request,res:express.Response){
    let Uid:number=parseInt(req.params.id)
    const user=users.filter(u=>u.Id===Uid)
    
    //creating token
    jwt.sign({user},"secretKey",{expiresIn:'300s'},(err,token)=>
    {
        res.status(400).json({
        token
        })

    })
    }

const server=http.createServer(expressapp);

server.listen(port)

let aaa={
    "user": [
        {
            "Id": 2,
            "Name": "SAGAR",
            "eMail": "sj@gmail.com"
        }
    ],
    "iat": 1671522037,
    "exp": 1671522337
}
