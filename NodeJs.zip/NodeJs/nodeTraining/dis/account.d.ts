export declare class account {
    accNo: number;
    constructor(accNo: number);
    showAccNo(): number;
}
