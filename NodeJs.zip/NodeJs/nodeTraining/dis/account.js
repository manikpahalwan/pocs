"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.account = void 0;
class account {
    constructor(accNo) {
        this.accNo = accNo;
    }
    showAccNo() {
        return this.accNo;
    }
}
exports.account = account;
let acc = new account(1);
console.log(acc.showAccNo());
