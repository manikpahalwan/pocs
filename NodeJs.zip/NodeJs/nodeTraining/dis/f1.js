"use strict";
function Hello() {
    console.log("Hello");
}
