"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = __importDefault(require("http"));
const path_1 = __importDefault(require("path"));
const formidable_1 = __importDefault(require("formidable"));
//specifying port number
const port = 9999;
const server = http_1.default.createServer();
server.on('request', (req, res) => {
    //setting path where to upload file
    let uploadpath = "C:\\Specialization\\NodeJs\\nodeTraining\\data\\upload";
    let form = new formidable_1.default.IncomingForm({
        // uploadDir:uploadpath,
        // keepExtensions:true     //by default formidable doesnt preserve filename nor file extension
        maxFileSize: 2200000000 //setting maximum file size
    });
    //event called as soon as data is available in the stream
    form.on("fileBegin", (key, value) => {
        console.log("fileBegin");
        value.filepath = path_1.default.join(uploadpath, value.originalFilename); //setting file path with original file name and extensions
    });
    //event called while file is being uploaded
    form.on("progress", (recived, expected) => {
        console.log("Recieved: " + recived); //total bytes uploaded
        console.log("Expected: " + expected); //total bytes to be uploaded (file size)
        console.log("   ");
    });
    //event called after file is uploaded
    form.on("file", (key, value) => {
        console.log("File Uploaded");
    });
    //event called incase of an error
    form.on("error", (error) => {
        console.log("Error:Something went wrong");
        console.log(error);
    });
    form.parse(req);
    res.end();
});
console.log("Server Listening To Port: " + port);
server.listen(port);
