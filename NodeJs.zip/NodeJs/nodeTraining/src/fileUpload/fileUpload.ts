import http, { IncomingMessage, ServerResponse } from 'http'
import path from 'path'
import formidable from 'formidable'
import IncomingForm from 'formidable/Formidable'    //default export in formidable

//specifying port number
const port:number=9999
const server=http.createServer();

server.on('request',(req:IncomingMessage,res:ServerResponse)=>{
    //setting path where to upload file
    let uploadpath:string="C:\\Specialization\\NodeJs\\nodeTraining\\data\\upload"

    let form:IncomingForm=new formidable.IncomingForm({     //creating instance of IncomingForm
        // uploadDir:uploadpath,
        // keepExtensions:true     //by default formidable doesnt preserve filename nor file extension
        maxFileSize:2200000000      //setting maximum file size
    });            
    //event called as soon as data is available in the stream
    form.on("fileBegin",(key:string,value:formidable.File)=>{
        console.log("fileBegin");
        value.filepath=path.join(uploadpath,value.originalFilename!);   //setting file path with original file name and extensions
    })

    //event called while file is being uploaded
    form.on("progress",(recived:number,expected:number)=>{
        console.log("Recieved: "+recived)    //total bytes uploaded
        console.log("Expected: "+expected) //total bytes to be uploaded (file size)
        console.log("   ")
    })

    //event called after file is uploaded
    form.on("file",(key:string,value:formidable.File)=>{
        console.log("File Uploaded")
    })
 
    //event called incase of an error
    form.on("error",(error)=>{
        console.log("Error:Something went wrong");
        console.log(error)
    }) 

    form.parse(req);
    res.end();
}
)
console.log("Server Listening To Port: "+port)
server.listen(port)
