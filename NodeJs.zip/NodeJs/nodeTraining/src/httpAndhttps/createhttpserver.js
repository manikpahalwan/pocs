"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = __importDefault(require("http"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
//importing url modeule to read portions of url
const url_1 = __importDefault(require("url"));
//settig port no
const port = 9999;
//creating server
const server = http_1.default.createServer();
server.timeout = 6000;
//ceating path
let dir = "C:\\Specialization\\NodeJs\\nodeTraining\\data";
let fileName = "sampleData.txt";
let filepath = path_1.default.join(dir, fileName);
// console.log(filepath)
//creating readable stream
const readable = fs_1.default.createReadStream(filepath);
//calling server
server.on("request", (req, res) => {
    console.log("Request recieved");
    res.write("Hello From NodeJS server");
    setTimeout(() => {
        res.write("Hello");
        // console.log("Hello")
    }, 1000);
    setTimeout(() => {
        res.write(" Bye");
        // console.log("Hi")
    }, 2000);
    setTimeout(() => {
        // res.end();
        // console.log("HiII")
    }, 4000);
    readable.on("data", (chunk) => {
        res.write(chunk);
    });
    // console.log(`Request Method:${req.method}`);        //returns request method (by default request method is get)
    // console.log(`Request Method:${JSON.stringify(req.headers)}`)         //returns request header
    // console.log(`Request URL:${req.url}`)                       //returns request url
    // res.setHeader("SERVERGREETING","Hello from Node Server")        //sets response header
    readable.on("end", () => {
        console.log("Closing Request Response");
        res.end();
    });
    //.parse('url u want to parse',true means parse query strings also)
    let requestUrl = url_1.default.parse(req.url, true); //object of UrlWuthParsedQuery
    console.log("Final Parsed url: " + JSON.stringify(requestUrl));
    console.log("Request Path: " + requestUrl.path); //returns complete path
    console.log("Request PathName: " + requestUrl.pathname);
    console.log("Request Query Strings: " + JSON.stringify(requestUrl.query)); //returns object
    const { id, name } = requestUrl.query; //array deconstruction
    console.log("Id: " + id);
    console.log("Name: " + name);
});
console.log("Server is listening on port: " + port);
server.listen(port);
