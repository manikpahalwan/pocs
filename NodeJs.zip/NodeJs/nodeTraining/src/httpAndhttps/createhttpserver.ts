import http, { IncomingMessage, Server, ServerResponse } from 'http'
import fs from 'fs'
import path from 'path'

//importing url modeule to read portions of url
import url, { UrlWithParsedQuery } from 'url'


//settig port no
const port:number=9999;

//creating server
const server:Server=http.createServer();
server.timeout=6000

//ceating path
let dir:string="C:\\Specialization\\NodeJs\\nodeTraining\\data"
let fileName:string="sampleData.txt"

let filepath:string=path.join(dir,fileName)
// console.log(filepath)

//creating readable stream
const readable=fs.createReadStream(filepath)


//calling server
server.on("request",(req:IncomingMessage,res:ServerResponse)=>{
    console.log("Request recieved")
    res.write("Hello From NodeJS server")
    
    setTimeout(()=>{
        res.write("Hello");
        // console.log("Hello")
    },1000);
    setTimeout(()=>{
        res.write(" Bye");
        // console.log("Hi")
    },2000);
    setTimeout(()=>{
        // res.end();
        // console.log("HiII")
        
    },4000);

    readable.on("data",(chunk)=>{
        res.write(chunk);
        
    })
    
    // console.log(`Request Method:${req.method}`);        //returns request method (by default request method is get)
    // console.log(`Request Method:${JSON.stringify(req.headers)}`)         //returns request header
    // console.log(`Request URL:${req.url}`)                       //returns request url

    // res.setHeader("SERVERGREETING","Hello from Node Server")        //sets response header

    readable.on("end",()=>{
        console.log("Closing Request Response")
        res.end();
    })

    //.parse('url u want to parse',true means parse query strings also)
    let requestUrl:UrlWithParsedQuery=url.parse(req.url!,true)      //object of UrlWuthParsedQuery
    console.log("Final Parsed url: "+JSON.stringify(requestUrl));
    console.log("Request Path: "+requestUrl.path)       //returns complete path
    console.log("Request PathName: "+requestUrl.pathname)   
    console.log("Request Query Strings: "+JSON.stringify(requestUrl.query))     //returns object

    const{id,name}=requestUrl.query;    //array deconstruction
    console.log("Id: "+id);
    console.log("Name: "+name);
})  

console.log("Server is listening on port: "+port);
server.listen(port)
