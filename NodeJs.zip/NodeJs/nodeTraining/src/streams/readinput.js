"use strict";
//default stream
let readable = process.stdin;
console.log("Enter some data.Type stop to quit");
//setting encoding for process.stdin
readable.setEncoding("utf8");
//calling event
//data is predefined event
// readable.on("data",(data:string)=>  //setting readable in flowing state
// {
//     if(data.trim()=="stop"){
//         readable.pause() //setting readable in pause state
//     }
//     console.log("Recieved: "+ data);
// })
//chaining of pipes using pipe
readable.pipe(process.stdout);
readable.on("data", (data) => //setting readable in flowing state
 {
    if (data.trim() == "stop") {
        readable.pause(); //setting readable in pause state
    }
});
