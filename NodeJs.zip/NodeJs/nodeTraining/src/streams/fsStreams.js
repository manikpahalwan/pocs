"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
//ceating path
let dir = "C:\\Specialization\\NodeJs\\nodeTraining\\data";
let fileName = "sampleData.txt";
let filepath = path_1.default.join(dir, fileName);
// console.log(filepath)
//creating readable stream
const readable = fs_1.default.createReadStream(filepath);
//putting chunk into writable stream (chaining readable and writable stream)
fileName = "writefile.txt";
filepath = path_1.default.join(dir, fileName);
// //ceating writable stream
const writable = fs_1.default.createWriteStream(filepath);
//piping read and write stream
readable.pipe(writable);
//calling readable stream
readable.on("data", (chunk) => {
    console.log(chunk);
    console.log(chunk.toString());
    //  asking node to wait until processing is over
    readable.pause();
    console.log(ProcessChunk(chunk.toString()));
    setTimeout(() => {
        readable.resume();
    }, 5000);
    // setTimeout(() => {
    //      writable.write(chunk)
    //     console.log("Chunk Written")
    // }, 10000);
    // console.log("Recieved Chunk")
    // writable.write(chunk)
    // console.log("Chunk written to file")
});
readable.on("end", () => {
    console.log("END OF FILE");
});
function ProcessChunk(chunk) {
    let content = chunk;
    content = content.toUpperCase();
    return content;
}
