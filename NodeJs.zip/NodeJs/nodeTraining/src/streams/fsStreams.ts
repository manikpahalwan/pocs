import fs from 'fs'
import path from 'path'
 
//ceating path
let dir:string="C:\\Specialization\\NodeJs\\nodeTraining\\data"
let fileName:string="sampleData.txt"

let filepath:string=path.join(dir,fileName)
// console.log(filepath)

//creating readable stream
const readable=fs.createReadStream(filepath)

//putting chunk into writable stream (chaining readable and writable stream)
fileName="writefile.txt";
filepath=path.join(dir,fileName)

// //ceating writable stream
const writable=fs.createWriteStream(filepath)

//piping read and write stream
readable.pipe(writable)

//calling readable stream
readable.on("data",(chunk)=>{
    console.log(chunk);
    console.log(chunk.toString());

    //  asking node to wait until processing is over
    readable.pause()   
    console.log(ProcessChunk(chunk.toString()));
    setTimeout(() => {
        readable.resume()
    }, 5000);

    // setTimeout(() => {
    //      writable.write(chunk)

    //     console.log("Chunk Written")
    // }, 10000);
    
    // console.log("Recieved Chunk")
    // writable.write(chunk)
    // console.log("Chunk written to file")
})
readable.on("end",()=>{
    console.log("END OF FILE");
})

   function ProcessChunk(chunk:string):string{
    let content:string=chunk;
    content=content.toUpperCase();
    return content;
}