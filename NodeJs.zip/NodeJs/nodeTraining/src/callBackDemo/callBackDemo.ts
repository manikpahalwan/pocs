//callBackDemo

function log(message:string,func:any) {
    func(message);
}

function DatabaseLogger(message:string) {
    console.log(`Logged Into DataBase: ${message}`)
}

function ConsoleLogger(message:string) {
    console.log(`Logged Into Console: ${message}`)
}

function FileLogger(message:string) {
    console.log(`Logged Into DataBase: ${message}`)
}
//passing arrow function as argument 
log("HELLO",DatabaseLogger)
log("HELLO",ConsoleLogger)
log("HELLO",FileLogger)
log("HELLO",(message:string) => console.log(`Logged Into Arrow: ${message}`) )