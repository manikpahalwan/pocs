"use strict";
//callBackDemo
function log(message, func) {
    func(message);
}
function DatabaseLogger(message) {
    console.log(`Logged Into DataBase: ${message}`);
}
function ConsoleLogger(message) {
    console.log(`Logged Into Console: ${message}`);
}
function FileLogger(message) {
    console.log(`Logged Into DataBase: ${message}`);
}
//passing arrow function as argument 
log("HELLO", DatabaseLogger);
log("HELLO", ConsoleLogger);
log("HELLO", FileLogger);
log("HELLO", (message) => console.log(`Logged Into Arrow: ${message}`));
