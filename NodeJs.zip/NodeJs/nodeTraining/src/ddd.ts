let id:number;

// printId(id)


function printId(i:number):string
{
    return ("Person's id is :i")
}

