function Hello():void {
    console.log("Hello")
}