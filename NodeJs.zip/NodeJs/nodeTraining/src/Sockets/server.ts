
import net from 'net';

const server:net.Server=net.createServer();     //eventemitter
const port:number=8888;

let clients:net.Socket[]=[]     //array to store and track the connected clients 

//event called when a client is connected
server.on("connection",(socket:net.Socket)=>{       //the socket from which client is making the connection the refrence on that socket is available in the callback
    console.log("A client Connected");
    clients.push(socket);
    console.log(`Total Clients: ${clients.length}`)

        

for (let index = 0; index < clients.length; index++) 
{
    clients[index].write("New Client Connected")
}
//socket is also an eventemitter
//event called whenever data is recieved on the socket 
socket.on("data",(data:string)=>{
    console.log(`Server Recieved: ${data}`)
})

//event called when client disconnects 
socket.on("close",(data:string)=>{
    console.log(`A client disconnected`)
})


}) 
server.listen(port,()=>{
    console.log(`TCP server listening on port ${port}`)
})