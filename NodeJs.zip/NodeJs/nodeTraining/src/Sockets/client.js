"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const net_1 = __importDefault(require("net"));
const port = 8888;
const socket = net_1.default.connect(port, "localhost", () => {
    console.log("Connected to Server");
});
//event called when client recieves data from server
socket.on("data", data => {
    console.log(`Client Recieved: ${data}`);
    socket.write(`Thanks from ${data}`); //wriring back to socket
});
setTimeout(() => {
    socket.destroy(); //simulating termination of comm by client
    //close event on server will be fired
}, 10000);
