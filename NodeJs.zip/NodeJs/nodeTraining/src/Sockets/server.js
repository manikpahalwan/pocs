"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const net_1 = __importDefault(require("net"));
const server = net_1.default.createServer(); //eventemitter
const port = 8888;
let clients = []; //array to store and track the connected clients 
//event called when a client is connected
server.on("connection", (socket) => {
    console.log("A client Connected");
    clients.push(socket);
    console.log(`Total Clients: ${clients.length}`);
    for (let index = 0; index < clients.length; index++) {
        clients[index].write("New Client Connected");
    }
    //socket is also an eventemitter
    //event called whenever data is recieved on the socket 
    socket.on("data", (data) => {
        console.log(`Server Recieved: ${data}`);
    });
    //event called when client disconnects 
    socket.on("close", (data) => {
        console.log(`A client disconnected`);
    });
});
server.listen(port, () => {
    console.log(`TCP server listening on port ${port}`);
});
