export class account {
    constructor(public accNo:number) {

    }
    public showAccNo():number {
    return this.accNo
    }
}

let acc:account=new account(1);

console.log(acc.showAccNo())