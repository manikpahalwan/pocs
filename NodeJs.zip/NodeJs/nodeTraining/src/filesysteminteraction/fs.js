"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//getting info abt certain file
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
let dirname = "C:\\Specialization\\NodeJs\\nodeTraining";
let filename = "data\\app.log";
let fullpath = path_1.default.join(dirname, filename);
console.log(fullpath);
//checking existance of file
console.log(path_1.default.basename(fullpath) + " exists ->" + fs_1.default.existsSync(fullpath));
//getting file statistics like size, last entity of path
fs_1.default.stat(fullpath, (error, stats) => {
    if (error) {
        console.log("Something went wrong");
        return;
    }
    console.log("IS A FILE ->" + stats.isFile());
    console.log("IS A FILE ->" + stats.isDirectory());
    console.log("FILE SIZE ->" + stats.size);
});
