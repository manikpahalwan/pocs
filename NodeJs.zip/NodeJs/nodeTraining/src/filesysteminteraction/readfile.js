"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
let dir = "C:\\Specialization\\NodeJs\\nodeTraining";
let filename = path_1.default.join(dir, "data\\app.log");
// console.log(filename)
//reading file sync
// let filecontents:string=fs.readFileSync(filename,"utf8")
// console.log(filecontents)
//reading file sync with try catch (error handling) 
let filecontents;
try {
    filecontents = fs_1.default.readFileSync(filename, "utf8");
    console.log(filecontents);
}
catch (error) {
    console.log("ERROR or EXCEPTION -> " + error);
}
// reading file async
// fs.readFile(filename,"utf8",(error,data)=>{
//     console.log(data)
// })
fs_1.default.readFile(filename, "utf8", (error, data) => {
    if (error) {
        console.log(error);
        console.log("SOMETHING WENT WRONG");
    }
    else {
        console.log(data);
    }
});
console.log("FILE HAS BEEN READ");
