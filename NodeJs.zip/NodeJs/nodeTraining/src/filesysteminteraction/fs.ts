//getting info abt certain file
import path from "path"
import fs from "fs"


let dirname:string="C:\\Specialization\\NodeJs\\nodeTraining";
let filename:string="data\\app.log";
let fullpath:string=path.join(dirname,filename)

console.log(fullpath)

//checking existance of file
console.log(path.basename(fullpath)+" exists ->"+fs.existsSync(fullpath))

//getting file statistics like size, last entity of path

fs.stat(fullpath,(error,stats)=>{
   if(error){console.log("Something went wrong")
    return
} 
   console.log("IS A FILE ->" +stats.isFile())
   console.log("IS A FILE ->" +stats.isDirectory())
   console.log("FILE SIZE ->" + stats.size)

})