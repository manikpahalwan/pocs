import fs from 'fs'
import path from 'path'

//using writeFile
let data:string=`My Name is Manik
I am 22 years old
`
let filepath:string="C:\\Specialization\\NodeJs\\nodeTraining\\data\\writefile.txt"
fs.writeFile(filepath,data,(error)=>{
    if(error){
        console.log("SOMETHING WENT WRONG")
        console.log(error)
    }
    else{
        console.log("FILE WRITTEN")
    }
}
)
fs.appendFile(filepath,data,(error)=>{
    if(error){
        console.log("SOMETHING WENT WRONG")
        console.log(error)
    }
    else{
        console.log("FILE WRITTEN")
    }
}
)