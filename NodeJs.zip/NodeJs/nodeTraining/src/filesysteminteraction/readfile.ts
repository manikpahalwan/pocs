import fs from 'fs'
import path from 'path'

let dir:string="C:\\Specialization\\NodeJs\\nodeTraining"
let filename:string=path.join(dir,"data\\app.log")
// console.log(filename)

//reading file sync
// let filecontents:string=fs.readFileSync(filename,"utf8")
// console.log(filecontents)

//reading file sync with try catch (error handling) 
let filecontents:string;
try {
    filecontents=fs.readFileSync(filename,"utf8");
    console.log(filecontents)
} catch (error:any) {
    console.log("ERROR or EXCEPTION -> "+error)
}

// reading file async
// fs.readFile(filename,"utf8",(error,data)=>{
//     console.log(data)
// })
fs.readFile(filename,"utf8",(error,data) => {
    if(error)
        {
        console.log(error)
        console.log("SOMETHING WENT WRONG")
        }
    else
        {
        console.log(data)
        }
});
console.log("FILE HAS BEEN READ")
