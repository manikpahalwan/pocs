import path from "path";

//global variables
console.log(__dirname);
console.log(__filename);
console.log(process.cwd());

//path module
console.log("Path Seperator --> "+path.sep)
console.log("Path delimeter --> "+path.delimiter)

let directories:string[]=['dir1','dir2','dir3']
let dir=directories.join(path.sep) 
//join directories in "directories" using path seperator
console.log("New Directory ->"+dir)

//using join with an object
// let filename:string=__filename;
// let dirname:string=__dirname
let filename="MANIK"
let dirname="CITIUSTECH"
let fullpath:string=path.join(dirname,filename)
console.log(fullpath)


console.log(path.dirname(dir))
console.log(path.dirname(__dirname)) //returns directory name only

console.log(path.basename(__dirname)) //returns either filename or directory name
console.log(path.extname(__dirname)) //returns extension of file if existing other wise ""

console.log(process.env) //returns obj containing info abt environment variable
console.log(process.env.path)