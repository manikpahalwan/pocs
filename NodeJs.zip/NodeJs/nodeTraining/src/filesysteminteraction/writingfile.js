"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
//using writeFile
let data = `My Name is Manik
I am 22 years old
`;
let filepath = "C:\\Specialization\\NodeJs\\nodeTraining\\data\\writefile.txt";
// fs.writeFile(filepath,data,(error)=>{
//     if(error){
//         console.log("SOMETHING WENT WRONG")
//         console.log(error)
//     }
//     else{
//         console.log("FILE WRITTEN")
//     }
// }
// )
fs_1.default.appendFile(filepath, data, (error) => {
    if (error) {
        console.log("SOMETHING WENT WRONG");
        console.log(error);
    }
    else {
        console.log("FILE WRITTEN");
    }
});
