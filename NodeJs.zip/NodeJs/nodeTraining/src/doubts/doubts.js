"use strict";
// let obj = {
//   hello: "Bye",
//   meta: {},
// };
// console.log(obj.meta);
// let a = obj.meta;
// // a.isOnHold=true;
// console.log(a);
// // a["isOnHold"]=true
// const x = [2, 4];
// x.push(1);
// console.log(x);
// const m = 1;
// let k = "";
// if (k) {
//   console.log("MANIK");
// } else {
//   console.log("MANIK PAHALWAN");
// }
// let jjj: string[] = [];
// let c = jjj[2];
// console.log(`C--> ${c}`);
// const ab = [1, 3, 4];
// ab.push(55);
// let ooo = undefined;
// if (ooo) {
//   console.log(`AB--> ${ab}`);
// }
// const taskSubjectDetailsMock = {
//   httpStatusCode: 200,
//   appCode: 1,
//   message: "success",
//   data: {
//     campaignTaskTeamsId: 175259,
//     campaignTaskTeamMeta: {
//       poTaskDetails: {
//         task_instance_uid: "7dc4fafc-46a0-4950-bd9e-00e1c8157a43",
//       },
//     },
//     isFlagged: 0,
//     isExpired: 0,
//     status: "completed",
//     statusMetaData: {
//       timer: "2",
//       className: "complete-status",
//       colorCode: "#05A28A",
//       expireKeys: ["reassign"],
//       filterStatusMap: "completed",
//     },
//     taskType: "1StepNBlindRead",
//     campign: {
//       id: 2107,
//       campaignName: "Demo_4222_1NB",
//       createdBy: 78,
//       meta: {
//         displayProtocol: "6075dc94e93f1b6b35565df1",
//       },
//     },
//     permissions: [
//       "canViewCampaign",
//       "canUpdateCampaign",
//       "canDeleteCampaign",
//       "canPublishCampaign",
//       "canReassignTask",
//       "canRetryTask",
//       "canSendReminder",
//       "canLaunchViewer",
//       "canGenerateReport",
//       "canShare",
//       "canDownloadQualitativeReport",
//       "canCreateArtifactOwnerId",
//       "canAddressEditCheck",
//       "canAccessCampaignSettings",
//       "canReopenTask",
//       "canDownloadQuantitativeReport",
//       "canDownloadAuditTrail",
//       "canHoldUnHoldTasks",
//       "canHoldUnHoldTasks",
//       "canHoldUnHoldTasks",
//       "canHoldUnHoldTasks",
//     ],
//     task: {
//       id: 76550,
//       dataId: 8888,
//       dataType: "SUBJECTS",
//       displayName: "Test_4222_1_11363",
//       status: "COMPLETED",
//       declineTaskToGroup: 1,
//     },
//     viewerDetails: {
//       id: 1,
//       targetViewerName: "HealthMyne",
//     },
//     stepsData: [
//       {
//         id: 72,
//         workflowId: 8,
//         stateName: "LESION_IDENTIFICATION",
//         meta: {
//           role: "Radiologist",
//           colorCode: "#D1EBE7",
//           shortName: "1- Rad",
//           sortOrder: 1,
//           toDisplay: true,
//           displayName: "Lesion Identification",
//           permissions: ["canExecute"],
//         },
//         teamMembersId: 62350,
//         assignedToName: "Priyanka Mhaske",
//         assignedToId: 78,
//         assignedToEmailId: ["mhaske.priyanka@gene.com"],
//         status: "completed",
//         statusMeta: {
//           timer: "2",
//           className: "complete-status",
//           colorCode: "#05A28A",
//           expireKeys: ["reassign"],
//           filterStatusMap: "completed",
//         },
//         isRetryRequired: false,
//         isFlagged: 0,
//         isExpired: 0,
//         campaignTaskAssignmentId: 878773,
//         viewerDetails: {
//           id: 1,
//           targetViewerName: "HealthMyne",
//         },
//         startedAt: "2023-01-17T09:59:41.000Z",
//         updatedAt: "2023-01-17T10:01:00.000Z",
//         taskAssignmentMeta: {
//           taskInstanceUId: "2981ad83-31d1-4be1-94ce-4f7361bba7cc",
//           firstHealthMyneId: "898fec68-de88-4af5-bd48-fe5aa7235e87",
//           ignoreEditCheckResultsByCO: false,
//         },
//         isReassigned: false,
//       },
//     ],
//     campaignTaskAssignmentId: 878773,
//     campaignTaskAssignmentMeta: {
//       taskInstanceUId: "2981ad83-31d1-4be1-94ce-4f7361bba7cc",
//       firstHealthMyneId: "898fec68-de88-4af5-bd48-fe5aa7235e87",
//       ignoreEditCheckResultsByCO: false,
//     },
//     isTeamFailed: false,
//     campaignTaskDocument: [
//       {
//         id: 81,
//       },
//     ],
//   },
//   failedLog: {},
//   errorMessage: "",
// };
// console.log(taskSubjectDetailsMock.data.campaignTaskDocument[0].id);
// const as = "Hello";
// if (as === "Hello") {
//   console.log(as);
// }
// let obj = [{
//     hello: "Bye",
//     meta: {},
//   }];
// if(obj[0].h){
//   console.log("Hello")
// }
// let aa:any = ['a','c','v']
// console.log(aa)
// const x= !aa.find((ele: any) => ele === 'a');
// console.log("x",x);
var m = 10;
var m = m + 100;
console.log(m);
