"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Mouse = void 0;
//mouse 
const events_1 = __importDefault(require("events")); //predefined module event has class eventemitter
class Mouse extends events_1.default {
    // private em:EventEmitter;
    constructor() {
        // this.em=new EventEmitter
        super();
    }
    ClickLeft() {
        //emit a click event
        // let clickevent:EventEmitter=new EventEmitter
        // this.em.emit("mouseclick","LEFT BUTTON")
        this.emit("mouseclick", "LEFT BUTTON");
    }
    ClickRight() {
        //emit a click event
        // let clickevent:EventEmitter=new EventEmitter
        // this.em.emit("mouseclick","RIGHT BUTTON")
        this.emit("mouseclick", "RIGHT BUTTON");
    }
}
exports.Mouse = Mouse;
