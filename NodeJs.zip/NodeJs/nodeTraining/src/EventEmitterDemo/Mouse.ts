//mouse 
import EventEmitter from "events";  //predefined module event has class eventemitter
export class Mouse extends EventEmitter{

    // private em:EventEmitter;
    constructor(){
        // this.em=new EventEmitter
        super()
    }

    public ClickLeft():void{
        //emit a click event
        // let clickevent:EventEmitter=new EventEmitter
        // this.em.emit("mouseclick","LEFT BUTTON")
        this.emit("mouseclick","LEFT BUTTON")
    }
    public ClickRight():void{
        //emit a click event
        // let clickevent:EventEmitter=new EventEmitter
        // this.em.emit("mouseclick","RIGHT BUTTON")
        this.emit("mouseclick","RIGHT BUTTON")
    }

    // public get MouseEvent(){
    //     return this.em;
    // } 
}