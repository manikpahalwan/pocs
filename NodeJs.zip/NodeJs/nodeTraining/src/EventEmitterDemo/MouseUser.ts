import { Mouse } from "./Mouse"

export class MouseUser{
    
    private mouse:Mouse;
    constructor(){
         this.mouse=new Mouse();
        //  this.mouse.MouseEvent.on("mouseclick",this.HandleMouseClick)
        this.mouse.on("mouseclick",this.HandleMouseClick)
    }

    public ClickLeftButton():void
    {
        // let m:Mouse=new Mouse()
        // this.mouse.MouseEvent.on("mouseclick",this.HandleMouseClick)
         this.mouse.ClickLeft();
        // this.mouse.ClickRight();
    }
    public ClickRightButton():void
    {
        // let m:Mouse=new Mouse()
        // this.mouse.MouseEvent.on("mouseclick",this.HandleMouseClick)
        // this.mouse.ClickLeft();
         this.mouse.ClickRight();
    }

    public HandleMouseClick(data:string){
        console.log(`USER PRESSED: ${data}`)
    }
}
let user:MouseUser=new MouseUser();
// user.ClickTheMouse();
user.ClickLeftButton();
user.ClickRightButton()

