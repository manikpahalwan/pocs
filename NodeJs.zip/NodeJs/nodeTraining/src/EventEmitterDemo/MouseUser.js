"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MouseUser = void 0;
const Mouse_1 = require("./Mouse");
class MouseUser {
    constructor() {
        this.mouse = new Mouse_1.Mouse();
        //  this.mouse.MouseEvent.on("mouseclick",this.HandleMouseClick)
        this.mouse.on("mouseclick", this.HandleMouseClick);
    }
    ClickLeftButton() {
        // let m:Mouse=new Mouse()
        // this.mouse.MouseEvent.on("mouseclick",this.HandleMouseClick)
        this.mouse.ClickLeft();
        // this.mouse.ClickRight();
    }
    ClickRightButton() {
        // let m:Mouse=new Mouse()
        // this.mouse.MouseEvent.on("mouseclick",this.HandleMouseClick)
        // this.mouse.ClickLeft();
        this.mouse.ClickRight();
    }
    HandleMouseClick(data) {
        console.log(`USER PRESSED: ${data}`);
    }
}
exports.MouseUser = MouseUser;
let user = new MouseUser();
// user.ClickTheMouse();
user.ClickLeftButton();
user.ClickRightButton();
