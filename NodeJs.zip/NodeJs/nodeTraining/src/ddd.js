"use strict";
let id;
// printId(id)
function printId(i) {
    return ("Person's id is :i");
}
