declare function Hello(): void;
