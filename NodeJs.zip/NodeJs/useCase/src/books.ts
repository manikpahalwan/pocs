export class book{

    constructor(
        public bookId:number=0,
        public bookName:string="",
        public publisher:string="",
        public cost:number=0
        
    ){}
}