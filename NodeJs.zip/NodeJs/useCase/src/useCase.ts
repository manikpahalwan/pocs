//ROUTING EXAMPLE

import http from 'http' //importing http 
import express from 'express'   //importing express
import bodyParser from 'body-parser';
import { book } from './books';
import fs from 'fs'


const port=9999;

//creating dummy database
let  books:book[]=[
    new book(1,"Learn NodeJs","MS Publishers",350.00),
    new book(2,"Learn ExpressJs","MS Publishers",325.00),
    new book(3,"Learn MySQL","ORACLE Publishers",400.00),
    new book(4,"Learn Angular","MS Publishers",330.00),
    new book(5,"Learn ReactJs","META Publishers",250.00),
    new book(6,"Learn Js","ECMA Publishers",250.00),
    new book(7,"Learn JQuery","ECMA Publishers",250.00),
    new book(8,"Learn JAVA","ORACLE Publishers",250.00),
];


//step1 Create an express app (container for a number of middleware)
const expressapp:express.Express=express();

expressapp.use(bodyParser.json());

//Create MiddleWare Logs the request type with date and time to a file named requestlogs.txt.
expressapp.use(logRequest)

//Create a middleware that Inserts a custom header with a datetime value on each HTTP request.
expressapp.use(customHeader);



//implementing routing

// GET  http://localhost:<<port>>/books . Returns all the books as JSON collection. Returns status code 200
expressapp.get("/books",GetAllBooks)  //handles request to get all books

// GET http://localhost:<<port>>/books/byid/<<bookid>> Returns a book for the specified bookid. 
// Returns OK if book exists, 404 otherwise
expressapp.get("/books/byid/:id",GetBookById)  //handles request to get a book by Id

// GET http://localhost:<<port>>/books/bypublisher/<<pubname>> 
// Returns all books for the specified publisher. Returns OK if book exists, 404 otherwise
expressapp.get("/books/bypublisher/:pname",GetBookByPublisher)  //handles request to get  books by Publisher name


// POST http://localhost:<<port>>/books/addbook 
// Adds a new book. Returns 201 after adding, Conflict if book id already exists
// Book details must be passed via request body
expressapp.post("/books/addbook",AddBook)  //handles request to a books


// PUT http://localhost:<<port>>/books/editbook/<<bookcode>>
// Edits a new book if exists. Returns 200 after editing 404 if bookid does not exist
// New Book details must be passed via request body
expressapp.put("/books/editbook/:id",EditBook)  //handles request to a books


// DELETE  http://localhost:<<port>>/books/deletebook/<<bookcode>>
// Deletes a new book if exists. Returns 200 after deleting 404 if bookid does not exist
expressapp.delete("/books/deletebook/:id",DeleteBook)  //handles request to a books




// Create an endpoint at http://localhost:<<port>>/getbooks.html which renders a view. The view must contain
// a button titled Get All Books when clicked must display a list of all books in an HTML table.

//using EJS view engine
expressapp.set("view engine","ejs")

//setting the path where the template can be found
expressapp.set("views","C:\\Specialization\\NodeJs\\useCase\\src\\viewengine\\views")

//rendering the view
expressapp.get("/getbooks.html",(req:express.Request,res:express.Response)=>{
    res.status(200).render("getBooks",{books});   //RENDERING THE VIEW
})



const server=http.createServer(expressapp);
console.log("REST API available on port: "+port)
//setting port
server.listen(port)

//Callback logics

//callback to get all books
function GetAllBooks(req:express.Request,res:express.Response)
{
    res.status(200).json(books)      //.json retuns a json object
}


//callback to get book by Id
function GetBookById(req:express.Request,res:express.Response)
{
    let bookId:number=parseInt(req.params.id)
    let result=books.filter(b=>b.bookId===bookId)   //extracting the book required

    if(result.length==0){
        res.status(404).send(`Error 404 Not Found`)
    }
    else{
        res.status(200).json(result)
    }
}

//callback to get books by publisher name
function GetBookByPublisher(req:express.Request,res:express.Response)
{
    let pname:string=req.params.pname
    let result=books.filter(p=>p.publisher===pname)   //extracting the books from publisher

    if(result.length==0){
        res.status(404).send(`Error 404 Not Found
        We don't have any book published by ${pname}`)
    }
    else{
        res.status(200).json(result)
    }
}


//callback to get add a new book
function AddBook(req:express.Request,res:express.Response)
{
    let newbook:book=req.body;
    let result=books.filter(book=>book.bookId===req.body.bookId)   //checking if the book exists or not
    if(result.length==0)
    {
    console.log(newbook);
    books.push(newbook);
    res.status(201).send("New Book Added")
    }

    else
    {   
        res.status(404).send("A Book With Same Id Already Exists")
    }
}

//callback to edit details of a book
function EditBook(req:express.Request,res:express.Response)
{
    let id:number=parseInt(req.params.id)
    let newbook:book=req.body;
    let result=books.filter(book=>book.bookId===id)   //checking if the book exists or not
    if(result.length==1)
    {
        for (let index = 0; index < books.length; index++) {
           if(books[index].bookId===id)
           {
                books[index].bookName=req.body.bookName
                books[index].cost=req.body.cost
                books[index].publisher=req.body.publisher
                res.status(200).send(`Book Updated`)
                break
           }
            
        }
    }
    else
    {   
        res.status(404).send("Kindly Check The BooK Id")
    }
}


//callback to delete a book
function DeleteBook(req:express.Request,res:express.Response)
{
    let id:number=parseInt(req.params.id)
    for (let index = 0; index < books.length; index++) {
        if(books[index].bookId===id)
        {
            books.splice(index, 1)      //deleting element
             res.status(200).send(`Book with Id ${id} deleted`)
             break
        }
    }
    res.status(404).send(`No Book with Id ${id} found`)

}


//middleware logging request details into file
let requestNo:number=1
function logRequest(request:express.Request,response:express.Response,next:any) 
{

    let date=new Date()
    let data=`Request Number:${requestNo},  RequestType:${request.method},  Date:${date} ,ReqURL:${request.url}
    `
    let filepath:string="C:\\Specialization\\NodeJs\\useCase\\src\\requestlogs.txt"

    fs.appendFile(filepath,data,(error)=>{
        if(error){
            console.log("SOMETHING WENT WRONG")
            console.log(error)
        }
        else{
            console.log("FILE WRITTEN")
            requestNo++
        }
    }
    )
    next();
}


//middleware setting custom header with date time
function customHeader(request:express.Request,response:express.Response,next:any) 
{
    let date=new Date()
    response.setHeader("DateTime","date")        //sets response header
    console.log(date)
    next();
}


