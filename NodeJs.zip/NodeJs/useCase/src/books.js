"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.book = void 0;
class book {
    constructor(bookId = 0, bookName = "", publisher = "", cost = 0) {
        this.bookId = bookId;
        this.bookName = bookName;
        this.publisher = publisher;
        this.cost = cost;
    }
}
exports.book = book;
