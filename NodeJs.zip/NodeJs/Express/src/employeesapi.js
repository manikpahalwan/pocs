"use strict";
//Router Example
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.employeesapi = void 0;
const express_1 = __importDefault(require("express")); //importing express
//step1 Create an express app (container for a number of middleware)
const employeesapi = express_1.default.Router();
exports.employeesapi = employeesapi;
//Routing
employeesapi.get("/", (req, res) => {
    res.status(200).send("Employees API -Default Route");
});
employeesapi.get("/allemployees", (req, res) => {
    res.status(200).send("Employees API -All Employees");
});
employeesapi.get("/employee/id", (req, res) => {
    res.status(200).send("Employees API -Employee By ID");
});
