//ROUTING EXAMPLE

import http from 'http' //importing http 
import express from 'express'   //importing express
import { Vehicle } from './vehicles';
import bodyParser from 'body-parser';
import { employeesapi } from './employeesapi';
import { booksapi } from './booksapi';

const port=9999;

//creating dummy database
let  vehicles:Vehicle[]=[
    new Vehicle(1,"Ford","Figo Aspire"),
    new Vehicle(2,"Ford","FresStyle"),
    new Vehicle(3,"Renualt","Kwid"),
    new Vehicle(4,"Renault","Duster"),
    new Vehicle(5,"Hyundai","I20"),
];


//step1 Create an express app (container for a number of middleware)
const expressapp:express.Express=express();

expressapp.use(bodyParser.json());


//routers  //techincal term ->middleware mounting
expressapp.use("/emp",employeesapi)
expressapp.use("/books",booksapi)



//implementing routing
expressapp.get("/vehicles",GetAllVehicles)  //handles request to get all vehicles
expressapp.get("/vehicle/:vid",GetVehicleById)  //handles request to get a vehicle by Id
expressapp.get("/vehicle/brand/:brand",GetVehicleByBrand)  //handles request to get vehicles by Brand name
expressapp.post("/addvehicle",AddVehicle)  //handles request to add a vehicle


const server=http.createServer(expressapp);
console.log("REST API available on port: "+port)
//setting port
server.listen(port)

function GetAllVehicles(req:express.Request,res:express.Response)
{
    res.status(200).json(vehicles)      //.json retuns a json object
}

function GetVehicleById(req:express.Request,res:express.Response)
{
    let vehicleid:number=parseInt(req.params.vid)
    let result=vehicles.filter(v=>v.VehicleId===vehicleid)
    

    if(result.length==0){
        res.status(404).send(`Vehicle with Id ${vehicleid} not found`)
    }
    else{
        res.status(200).json(result)
    }
}

function GetVehicleByBrand(req:express.Request,res:express.Response)
{
    let brand:string=req.params.brand
    let result=vehicles.filter(v=>v.Brand===brand)

    if(result.length==0){
        res.status(404).send(`Vehicle with Id ${brand} not found`)
    }
    else{
        res.status(200).json(result)
    }
}
function AddVehicle(req:express.Request,res:express.Response)
{
    let newvehicle:Vehicle=req.body;
    console.log(newvehicle);
    vehicles.push(newvehicle);
    res.status(201).send("New Vehicle Added")
}
