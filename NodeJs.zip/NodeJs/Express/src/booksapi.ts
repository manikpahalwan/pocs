//Router Example

import express from 'express'   //importing express

//step1 Create an express app (container for a number of middleware)
const booksapi=express.Router();

//Routing
booksapi.get("/",(req:express.Request,res:express.Response)=>{
    res.status(200).send("Books API -Default Route");
})

booksapi.get("/allbooks",(req:express.Request,res:express.Response)=>{
    res.status(200).send("Books API -All Books");
})

booksapi.get("/book/id",(req:express.Request,res:express.Response)=>{
    res.status(200).send("Books API -Book By ID");
})

export{booksapi}    //exporting the router