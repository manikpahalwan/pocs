import http from 'http' //importing http 
import express from 'express'   //importing express

const port=9999;
const expressapp:express.Express=express();
  

//tell expressjs to use EJS view engine
expressapp.set("view engine","ejs")

//setting the path where the template can be found
expressapp.set("views","C:\\Specialization\\NodeJs\\Express\\src\\viewengine\\viewsx")

expressapp.get("/",(req:express.Request,res:express.Response)=>{
    res.status(200).render("home");   //RENDERING THE VIEW
})


expressapp.get("/about",(req:express.Request,res:express.Response)=>{
    res.status(200).render("about");   //RENDERING THE VIEW
})



expressapp.get("/data",(req:express.Request,res:express.Response)=>{

    let data:string="HELLO MANIK"
    res.status(200).render("data",{viewdata:data});   //RENDERING THE VIEW and data to pass to the template 2nd parameter must be an object of key value pairs
})

expressapp.get("/patientlist",(req:express.Request,res:express.Response)=>{
    let patientlist:any[]=[
        {"pid":1,"pname":"P1","age":20},
        {"pid":2,"pname":"P2","age":22},
        {"pid":3,"pname":"P3","age":24}
    ]
    res.status(200).render("patientlist",{patientlist})     //no need to metion key if key name has same name as of data
})  


expressapp.get("*",(req:express.Request,res:express.Response)=>{
    res.status(404).render("error");   //RENDERING THE VIEW
})

const server=http.createServer(expressapp);
server.listen(port)

