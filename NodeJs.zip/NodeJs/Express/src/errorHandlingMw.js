"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = __importDefault(require("http")); //importing http 
const express_1 = __importDefault(require("express")); //importing express
const port = 9999;
//step1 Create an express app (container for a number of middleware)
const expressapp = (0, express_1.default)();
//step3 plugin the middlewares
expressapp.use(NormalMiddleware);
expressapp.use(Logger);
expressapp.use(ErrorHandlingMiddleware); //good practice to call ErrorhandlingMw at last
//creating normal middleware
function NormalMiddleware(request, response, next) {
    if (10 < 20) {
        response.status(200).send("Normal MiddleWare! All Good");
        next();
    }
    else {
        next(new Error("THERE WAS SOME ERROR"));
    }
}
//creating normal middleware
function Logger(request, response, next) {
    // response.status(2525).send("THANK GOD NO ERROR")
    console.log("THANK GOD NO ERROR");
}
//creating Error handling middleware
function ErrorHandlingMiddleware(error, request, response, next) {
    response.status(500).send("Error --> " + error);
}
//Step2 Tell Node Server about the express app
const server = http_1.default.createServer(expressapp);
console.log("Server listening on port: " + port);
//setting port
server.listen(port);
