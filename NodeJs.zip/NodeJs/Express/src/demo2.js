"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = __importDefault(require("http")); //importing http 
const express_1 = __importDefault(require("express")); //importing express
const port = 9999;
//step1 Create an express app (container for a number of middleware)
const expressapp = (0, express_1.default)();
//step3 plugin the middlewares
expressapp.use(express_1.default.static("C:\\Specialization\\NodeJs\\Express\\public")); //requires to specify the folder from where files are to be served 
expressapp.use((request, response) => {
    response.status(200).send("Hello");
});
//Step2 Tell Node Server about the express app
const server = http_1.default.createServer(expressapp);
console.log("Server listening on port: " + port);
//setting port
server.listen(port);
