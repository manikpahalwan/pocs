export class Vehicle{

    constructor(
        public VehicleId:number=0,
        public Brand:string="",
        public Model:string=""
    ){}
}