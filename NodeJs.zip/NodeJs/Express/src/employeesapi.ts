//Router Example

import express from 'express'   //importing express

//step1 Create an express app (container for a number of middleware)
const employeesapi=express.Router();

//Routing
employeesapi.get("/",(req:express.Request,res:express.Response)=>{
    res.status(200).send("Employees API -Default Route");
})

employeesapi.get("/allemployees",(req:express.Request,res:express.Response)=>{
    res.status(200).send("Employees API -All Employees");
})

employeesapi.get("/employee/id",(req:express.Request,res:express.Response)=>{
    res.status(200).send("Employees API -Employee By ID");
})

export{employeesapi}    //exporting the router