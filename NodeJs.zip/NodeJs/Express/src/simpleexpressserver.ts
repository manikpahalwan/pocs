import http from 'http' //importing http 
import express from 'express'   //importing express

const port=9999;

//step1 Create an express app (container for a number of middleware)
const expressapp:express.Express=express();

//step3 plugin the middlewares
expressapp.use(Middleware1)
expressapp.use(Middleware2)

//Step2 Tell Node Server about the express app
const server=http.createServer(expressapp);
console.log("Server listening on port: "+port)

//setting port
server.listen(port)

//creating middlewares

function Middleware1(request:express.Request,response:express.Response,next:any) 
{
    response.setHeader("Message","HELLO FROM EXPRESS JS")
    // console.log("MiddleWare_1")    
    next();
}

function Middleware2(request:express.Request,response:express.Response,next:any) 
{
    console.log("MiddleWare_2")    
    response.setHeader("Content-Type","text/html")
    response.status(200).send("<h1>From Middeleware_2</h2>")
    // response.send("<h1>Hello</h2>")
}