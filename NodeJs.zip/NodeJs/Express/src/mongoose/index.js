"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express")); //importing express
const properties_1 = require("./properties");
const app = (0, express_1.default)();
//step1 importing mongoDB
const mongoose = require("mongoose");
//step 2 is to create properties.ts file
//step 3 import properties file
let property = new properties_1.properties();
console.log(property.db_url);
//step 4 
mongoose.connect(property.db_url);
//step5 
mongoose.connection.on("connected", () => {
    console.log("Connected to MongoDb using MongooseJS");
});
