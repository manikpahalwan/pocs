"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.properties = void 0;
class properties {
    constructor(db_port = 4300, db_url = "mongodb://localhost:27017/CRM") {
        this.db_port = db_port;
        this.db_url = db_url;
    }
}
exports.properties = properties;
