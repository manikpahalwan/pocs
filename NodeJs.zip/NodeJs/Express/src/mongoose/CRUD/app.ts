import mongoose from "mongoose";
import http from 'http'
import express from 'express'   //importing express
import {Student } from "./student";
import { create } from "domain";
import bodyParser from 'body-parser';
import { studentsapi } from './students';
const port=9999;

//step1 Create an express app (container for a number of middleware)
const expressapp:express.Express=express();

mongoose.connect('mongodb://localhost/ManikDataBase',()=>{
    console.log("CONNECTED")
})
expressapp.use(bodyParser.json());
expressapp.use("/students",studentsapi)
expressapp.use("/students/add",studentsapi)
expressapp.use("/readAll",studentsapi)
expressapp.use("/update",studentsapi)
expressapp.use("/delete",studentsapi)


const server=http.createServer(expressapp);
console.log("REST API available on port: "+port)
//setting port
server.listen(port)