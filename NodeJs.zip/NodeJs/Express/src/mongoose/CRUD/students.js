"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.studentsapi = void 0;
const express_1 = __importDefault(require("express")); //importing express
//importing schema
const student_1 = require("./student");
//step1 Create an express app (container for a number of middleware)
const studentsapi = express_1.default.Router();
exports.studentsapi = studentsapi;
//Routing
studentsapi.get("/", (req, res) => {
    res.status(200).send("Students");
});
//<-------------------------------------------------------------------------------------------------------------------------------------->
//Create /add
studentsapi.post("/add", (req, res) => {
    // const student = new Student({
    //     studentId:1,
    //     firstName: 'SOHAM',
    //     lastName: 'LOHAR',
    //     age: 22
    // })
    const student = new student_1.Student({
        studentId: req.body.studentId,
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        age: req.body.age
    });
    student.save(function (err, student) {
        if (err)
            res.status(404).send(err);
        else
            res.status(200).send({ message: "USER ADDED SUCESSFULLY",
                studentObj: student });
    });
    // student.save()
});
//<-------------------------------------------------------------------------------------------------------------------------------------->
//Read 
//read all
studentsapi.get("/readAll", (req, res) => {
    student_1.Student.find(function (err, response) {
        if (err)
            res.status(404).send(err);
        else
            res.status(200).send({
                students: response
            });
    });
});
//read by condition
studentsapi.get("/searchByfirstName", (req, res) => {
    //parsing the query to get parameter firstName
    let fName = req.query.firstName;
    student_1.Student.find({ firstName: fName }, function (err, response) {
        if (err)
            res.status(404).send(err);
        else
            res.status(200).send({
                students: response
            });
    });
});
//read by unique id
studentsapi.get("/searchById", (req, res) => {
    //parsing the query to get ID
    let Id = req.query.Id;
    student_1.Student.findById(Id, function (err, response) {
        if (err)
            res.status(404).send(err);
        else
            res.status(200).send({
                students: response
            });
    });
});
//<-------------------------------------------------------------------------------------------------------------------------------------->
//Update
//update all that match condition
studentsapi.put("/update", (req, res) => {
    //parsing the query to get parameter
    const fName = req.query.firstName;
    const lName = req.query.lastName;
    student_1.Student.update({ firstName: fName, lastName: lName }, { age: 25 }, function (err, response) {
        if (err)
            res.status(404).send(err);
        else
            res.status(200).send({
                students: response
            });
    });
});
//update by Id
studentsapi.put("/update/User", (req, res) => {
    //parsing the query to get parameter
    const UId = req.query.UserId;
    student_1.Student.findByIdAndUpdate(UId, { age: 100 }, function (err, response) {
        if (err)
            res.status(404).send(err);
        else
            res.status(200).send({
                students: response
            });
    });
});
//find one and update finds first and update it onle 
studentsapi.put("/update/UserFirst", (req, res) => {
    //parsing the query to get parameter
    const fName = req.query.firstName;
    student_1.Student.findOneAndUpdate({ firstName: fName }, { age: 101 }, function (err, response) {
        if (err)
            res.status(404).send(err);
        else
            res.status(200).send({
                students: response
            });
    });
});
//<-------------------------------------------------------------------------------------------------------------------------------------->
//Delete
//delete by Id
studentsapi.delete("/delete/User", (req, res) => {
    //parsing the query to get parameter
    const UId = req.query.UserId;
    student_1.Student.findByIdAndDelete(UId, function (err, response) {
        if (err)
            res.status(404).send(err);
        else
            res.status(200).send({
                students: response
            });
    });
});
//remove by criteria
studentsapi.delete("/delete", (req, res) => {
    //parsing the query to get parameter
    const fName = req.query.firstName;
    student_1.Student.remove({ firstName: fName }, (err) => {
        if (err) {
            res.status(404).send(err);
        }
        else
            res.status(200).send(`All Students with name ${fName} deleted`);
    });
});
//fineOneAndRemove
studentsapi.delete("/deleteOne", (req, res) => {
    //parsing the query to get parameter
    const fName = req.query.firstName;
    student_1.Student.findOneAndRemove({ firstName: fName }, (err) => {
        if (err) {
            res.status(404).send(err);
        }
        else
            res.status(200).send(`First Student with name ${fName} deleted`);
    });
});
