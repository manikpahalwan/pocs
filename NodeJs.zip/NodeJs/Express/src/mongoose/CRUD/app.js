"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = __importDefault(require("mongoose"));
const http_1 = __importDefault(require("http"));
const express_1 = __importDefault(require("express")); //importing express
const body_parser_1 = __importDefault(require("body-parser"));
const students_1 = require("./students");
const port = 9999;
//step1 Create an express app (container for a number of middleware)
const expressapp = (0, express_1.default)();
mongoose_1.default.connect('mongodb://localhost/ManikDataBase', () => {
    console.log("CONNECTED");
});
expressapp.use(body_parser_1.default.json());
expressapp.use("/students", students_1.studentsapi);
expressapp.use("/students/add", students_1.studentsapi);
expressapp.use("/readAll", students_1.studentsapi);
expressapp.use("/update", students_1.studentsapi);
expressapp.use("/delete", students_1.studentsapi);
const server = http_1.default.createServer(expressapp);
console.log("REST API available on port: " + port);
//setting port
server.listen(port);
