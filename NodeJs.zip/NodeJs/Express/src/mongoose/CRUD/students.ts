//Router 
import mongoose from "mongoose";
import express from 'express'   //importing express
//importing schema
import { Student } from "./student";

//step1 Create an express app (container for a number of middleware)
const studentsapi = express.Router();

//Routing
studentsapi.get("/", (req: express.Request, res: express.Response) => {
    res.status(200).send("Students");
})

//<-------------------------------------------------------------------------------------------------------------------------------------->
//Create /add
studentsapi.post("/add",(req: express.Request, res: express.Response) => {
    // const student = new Student({
    //     studentId:1,
    //     firstName: 'SOHAM',
    //     lastName: 'LOHAR',
    //     age: 22
    // })
    const student = new Student({
        studentId: req.body.studentId,
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        age: req.body.age
    })
    student.save(function(err,student)    {
        if(err) 
            res.status(404).send(err);
        else 
            res.status(200).send({message:"USER ADDED SUCESSFULLY",
            studentObj:student});
    })
    // student.save()
})

//<-------------------------------------------------------------------------------------------------------------------------------------->
//Read 
//read all
studentsapi.get("/readAll", (req: express.Request, res: express.Response) => {
    
    Student.find(function(err,response)    {
        if(err) 
            res.status(404).send(err);
        else 
            res.status(200).send({
                students:response

            });
    })
})


//read by condition
studentsapi.get("/searchByfirstName", (req: express.Request, res: express.Response) => {

    //parsing the query to get parameter firstName
    let fName=req.query.firstName

    Student.find({firstName:fName},function(err: any,response: any)    {
        if(err) 
            res.status(404).send(err);
        else 
            res.status(200).send({
                students:response

            });
    })
})

//read by unique id
studentsapi.get("/searchById", (req: express.Request, res: express.Response) => {

    //parsing the query to get ID
    
    let Id=req.query.Id
    Student.findById(Id,function(err: any,response: any)    {
        if(err) 
            res.status(404).send(err);
        else 
            res.status(200).send({
                students:response

            });
    })
})

//<-------------------------------------------------------------------------------------------------------------------------------------->
//Update

//update all that match condition

studentsapi.put("/update", (req: express.Request, res: express.Response) => {

    //parsing the query to get parameter
    const fName=req.query.firstName
    const lName=req.query.lastName

    Student.update({firstName:fName,lastName:lName},{age:25},function(err: any,response: any)    {
        if(err) 
            res.status(404).send(err);
        else 
            res.status(200).send({
                students:response

            });
    })
})

//update by Id
studentsapi.put("/update/User", (req: express.Request, res: express.Response) => {

    //parsing the query to get parameter
    const UId=req.query.UserId
    Student.findByIdAndUpdate(UId,{age:100},function(err: any,response: any)    {
        if(err) 
            res.status(404).send(err);
        else 
            res.status(200).send({
                students:response

            });
    })
})

//find one and update finds first and update it onle 
studentsapi.put("/update/UserFirst", (req: express.Request, res: express.Response) => {

    //parsing the query to get parameter
    const fName=req.query.firstName
    Student.findOneAndUpdate({firstName:fName},{age:101},function(err: any,response: any)    {
        if(err) 
            res.status(404).send(err);
        else 
            res.status(200).send({
                students:response

            });
    })
})


//<-------------------------------------------------------------------------------------------------------------------------------------->
//Delete

//delete by Id
studentsapi.delete("/delete/User", (req: express.Request, res: express.Response) => {

    //parsing the query to get parameter
    const UId=req.query.UserId
    Student.findByIdAndDelete(UId,function(err: any,response: any)    {
        if(err) 
            res.status(404).send(err);
        else 
            res.status(200).send({
                students:response

            });
    })
})


//remove by criteria
studentsapi.delete("/delete", (req: express.Request, res: express.Response) => {

    //parsing the query to get parameter
    const fName=req.query.firstName
    Student.remove({firstName:fName},(err)=>{
        if(err) 
        {
            res.status(404).send(err)
        }
        else 
            res.status(200).send(`All Students with name ${fName} deleted`);
    })
})

//fineOneAndRemove
studentsapi.delete("/deleteOne", (req: express.Request, res: express.Response) => {

    //parsing the query to get parameter
    const fName=req.query.firstName
    Student.findOneAndRemove({firstName:fName},(err: any)=>{
        if(err) 
        {
            res.status(404).send(err)
        }
        else 
            res.status(200).send(`First Student with name ${fName} deleted`);
    })
})
//  db.students.insert({
//     'id':22,
//     'firstName': 'Harry',
//     'lastName':'Potter',
//     'age': 5
//  })

//exporting router
export { studentsapi }