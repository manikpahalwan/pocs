import mongoose from "mongoose";

//creating schema
let studentSchema=new mongoose.Schema({
    studentId:Number,
    firstName:String,
    lastName:String,
    age:Number
})

//creating model
export const Student= mongoose.model("Student",studentSchema)