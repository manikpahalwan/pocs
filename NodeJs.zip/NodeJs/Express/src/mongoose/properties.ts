export class properties{
    constructor(
        public db_port:number=4300,
        public db_url:string="mongodb://localhost:27017/CRM"
    ){}
}