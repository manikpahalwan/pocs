import express from 'express'   //importing express
import { properties } from './properties';
const app: express.Express=express();

//step1 importing mongoDB
const mongoose = require("mongoose")

//step 2 is to create properties.ts file

//step 3 import properties file
let property:properties=new properties() 
console.log(property.db_url);

//step 4 
mongoose.connect(property.db_url);

//step5 
mongoose.connection.on("connected",()=>{
    console.log("Connected to MongoDb using MongooseJS")
})