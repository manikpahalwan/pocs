import http from 'http' //importing http 
import express from 'express'   //importing express

const port=9999;

//step1 Create an express app (container for a number of middleware)
const expressapp:express.Express=express();

//step3 plugin the middlewares
expressapp.use(NormalMiddleware)
expressapp.use(Logger)
expressapp.use(ErrorHandlingMiddleware)     //good practice to call ErrorhandlingMw at last



//creating normal middleware
function NormalMiddleware(request:express.Request,response:express.Response,next:any) 
{
    if(10<20){
        response.status(200).send("Normal MiddleWare! All Good")
        next()
    }
    else{
        next(new Error("THERE WAS SOME ERROR"))
    }
}


//creating normal middleware
function Logger(request:express.Request,response:express.Response,next:any) 
{
    // response.status(2525).send("THANK GOD NO ERROR")
    console.log("THANK GOD NO ERROR")
}

//creating Error handling middleware
function ErrorHandlingMiddleware(error:Error,request:express.Request,response:express.Response,next:any) 
{
    response.status(500).send("Error --> "+error)
}

//Step2 Tell Node Server about the express app
const server=http.createServer(expressapp);
console.log("Server listening on port: "+port)

//setting port
server.listen(port)