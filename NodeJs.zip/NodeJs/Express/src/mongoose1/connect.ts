import mongoose from "mongoose";

mongoose.connect("mongodb://localhost:27017/ManikDataBase",()=>{
    console.log("Connected")
})

//importing model
import { User } from "./user";

const user=new User({name:'MANIK',age:22})
user.save()