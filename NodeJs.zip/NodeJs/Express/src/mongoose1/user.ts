import mongoose from "mongoose";

//creating schema
const userSchema=new mongoose.Schema({
    name:String,
    age:Number
})

//creating model
export const User= mongoose.model("User",userSchema)
