"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = __importDefault(require("http")); //importing http 
const express_1 = __importDefault(require("express")); //importing express
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken")); //importing express
const secretKey = "secretKey";
const port = 9999;
const expressapp = (0, express_1.default)();
expressapp.get("/", (req, res) => {
    res.status(400).send("HELLO");
});
expressapp.post("/login", (req, res) => {
    const user = {
        id: 1,
        username: "MANIK PAHALWAN",
        email: "mp@gmail.com"
    };
    jsonwebtoken_1.default.sign({ user }, "secretKey", { expiresIn: '300s' }, (err, token) => {
        res.status(400).json({
            token
        });
    });
});
expressapp.post("/profile", verifyToken, (req, res) => {
    jsonwebtoken_1.default.verify(req.params.token, secretKey, (err, authData) => {
        if (err)
            res.status(404).send("INVALID TOKEN");
        else {
            res.status(400).json({
                message: "profile accessed",
                authData
            });
        }
    });
});
function verifyToken(req, res, next) {
    const bearerHeader = req.headers['authorization'];
    if (typeof bearerHeader !== 'undefined') {
        const bearer = bearerHeader.split(" ");
        const token = bearer[1];
        req.params.token = token;
        next();
    }
    else {
        res.status(404).send({
            result: "Token is Not Valid"
        });
    }
}
const server = http_1.default.createServer(expressapp);
server.listen(port);
let match = [];
match.push({ "candidate_index": 1,
    "skill_no": 5
});
let obj_toSend;
let z = 0;
// for(let i=0;i<2;i++){
// if(match[i].skill_no>z){
// obj_toSend=i
// z=i
// }
// }
let val = match[0];
console.log(val);
const user = {
    id: 1,
    username: "MANIK PAHALWAN",
    email: "mp@gmail.com"
};
// console.log(obj_toSend)//
console.log(user.id);
