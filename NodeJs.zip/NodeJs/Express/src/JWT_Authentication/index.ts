import http from 'http' //importing http 
import express from 'express'   //importing express

import jwt from 'jsonwebtoken'   //importing express
import { appendFile } from 'fs';
import { User } from '../mongoose1/user';
const secretKey:string="secretKey"
const port=9999;

const expressapp:express.Express=express();

expressapp.get("/",(req:express.Request,res:express.Response)=>{
res.status(400).send("HELLO")
})

expressapp.post("/login",(req:express.Request,res:express.Response)=>{
    
    const user={
        id:1,
        username:"MANIK PAHALWAN",
        email:"mp@gmail.com"
    }
    jwt.sign({user},"secretKey",{expiresIn:'300s'},(err,token)=>
    {
        res.status(400).json({
        token
        })

    })
    })

expressapp.post("/profile",verifyToken,(req:express.Request,res:express.Response)=>{
    jwt.verify(req.params.token,secretKey,(err,authData)=>{
        if(err) res.status(404).send("INVALID TOKEN")
        else{
            res.status(400).json({
                message:"profile accessed",
                authData
            })
        }
    })
})
    
function verifyToken(req:express.Request,res:express.Response,next:any){
const bearerHeader=req.headers['authorization'];
if(typeof bearerHeader !=='undefined'){
    const bearer=bearerHeader.split(" ")
    const token =bearer[1];
    req.params.token=token
    next();
}
else{
    res.status(404).send({
        result:"Token is Not Valid"
    })
}


}

const server=http.createServer(expressapp);

server.listen(port)




let match=[]
match.push({"candidate_index":1,
"skill_no":5
})

let obj_toSend;
let z =0
// for(let i=0;i<2;i++){
// if(match[i].skill_no>z){
// obj_toSend=i
// z=i
// }
// }
let val=match[0]
console.log(val)
const user={
    id:1,
    username:"MANIK PAHALWAN",
    email:"mp@gmail.com"
}
// console.log(obj_toSend)//
console.log(user.id)