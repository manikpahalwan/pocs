"use strict";
//ROUTING EXAMPLE
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = __importDefault(require("http")); //importing http 
const express_1 = __importDefault(require("express")); //importing express
const vehicles_1 = require("./vehicles");
const body_parser_1 = __importDefault(require("body-parser"));
const employeesapi_1 = require("./employeesapi");
const booksapi_1 = require("./booksapi");
const port = 9999;
//creating dummy database
let vehicles = [
    new vehicles_1.Vehicle(1, "Ford", "Figo Aspire"),
    new vehicles_1.Vehicle(2, "Ford", "FresStyle"),
    new vehicles_1.Vehicle(3, "Renualt", "Kwid"),
    new vehicles_1.Vehicle(4, "Renault", "Duster"),
    new vehicles_1.Vehicle(5, "Hyundai", "I20"),
];
//step1 Create an express app (container for a number of middleware)
const expressapp = (0, express_1.default)();
expressapp.use(body_parser_1.default.json());
//routers  //techincal term ->middleware mounting
expressapp.use("/emp", employeesapi_1.employeesapi);
expressapp.use("/books", booksapi_1.booksapi);
//implementing routing
expressapp.get("/vehicles", GetAllVehicles); //handles request to get all vehicles
expressapp.get("/vehicle/:vid", GetVehicleById); //handles request to get a vehicle by Id
expressapp.get("/vehicle/brand/:brand", GetVehicleByBrand); //handles request to get vehicles by Brand name
expressapp.post("/addvehicle", AddVehicle); //handles request to add a vehicle
const server = http_1.default.createServer(expressapp);
console.log("REST API available on port: " + port);
//setting port
server.listen(port);
function GetAllVehicles(req, res) {
    res.status(200).json(vehicles); //.json retuns a json object
}
function GetVehicleById(req, res) {
    let vehicleid = parseInt(req.params.vid);
    let result = vehicles.filter(v => v.VehicleId === vehicleid);
    if (result.length == 0) {
        res.status(404).send(`Vehicle with Id ${vehicleid} not found`);
    }
    else {
        res.status(200).json(result);
    }
}
function GetVehicleByBrand(req, res) {
    let brand = req.params.brand;
    let result = vehicles.filter(v => v.Brand === brand);
    if (result.length == 0) {
        res.status(404).send(`Vehicle with Id ${brand} not found`);
    }
    else {
        res.status(200).json(result);
    }
}
function AddVehicle(req, res) {
    let newvehicle = req.body;
    console.log(newvehicle);
    vehicles.push(newvehicle);
    res.status(201).send("New Vehicle Added");
}
