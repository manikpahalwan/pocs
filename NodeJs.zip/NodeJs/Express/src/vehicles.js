"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Vehicle = void 0;
class Vehicle {
    constructor(VehicleId = 0, Brand = "", Model = "") {
        this.VehicleId = VehicleId;
        this.Brand = Brand;
        this.Model = Model;
    }
}
exports.Vehicle = Vehicle;
