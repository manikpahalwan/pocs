"use strict";
//Router Example
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.booksapi = void 0;
const express_1 = __importDefault(require("express")); //importing express
//step1 Create an express app (container for a number of middleware)
const booksapi = express_1.default.Router();
exports.booksapi = booksapi;
//Routing
booksapi.get("/", (req, res) => {
    res.status(200).send("Books API -Default Route");
});
booksapi.get("/allbooks", (req, res) => {
    res.status(200).send("Books API -All Books");
});
booksapi.get("/book/id", (req, res) => {
    res.status(200).send("Books API -Book By ID");
});
