import http from 'http' //importing http 
import express from 'express'   //importing express

const port=9999;

//step1 Create an express app (container for a number of middleware)
const expressapp:express.Express=express();

//step3 plugin the middlewares
expressapp.use(express.static("C:\\Specialization\\NodeJs\\Express\\public"))    //requires to specify the folder from where files are to be served 

expressapp.use((request:express.Request,response:express.Response)=>{
    response.status(200).send("Hello")
})


//Step2 Tell Node Server about the express app
const server=http.createServer(expressapp);
console.log("Server listening on port: "+port)

//setting port
server.listen(port)