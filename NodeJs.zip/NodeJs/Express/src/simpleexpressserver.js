"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = __importDefault(require("http")); //importing http 
const express_1 = __importDefault(require("express")); //importing express
const port = 9999;
//step1 Create an express app (container for a number of middleware)
const expressapp = (0, express_1.default)();
//step3 plugin the middlewares
expressapp.use(Middleware1);
expressapp.use(Middleware2);
//Step2 Tell Node Server about the express app
const server = http_1.default.createServer(expressapp);
console.log("Server listening on port: " + port);
//setting port
server.listen(port);
//creating middlewares
function Middleware1(request, response, next) {
    response.setHeader("Message", "HELLO FROM EXPRESS JS");
    // console.log("MiddleWare_1")    
    next();
}
function Middleware2(request, response, next) {
    console.log("MiddleWare_2");
    response.setHeader("Content-Type", "text/html");
    response.status(200).send("<h1>From Middeleware_2</h2>");
    // response.send("<h1>Hello</h2>")
}
