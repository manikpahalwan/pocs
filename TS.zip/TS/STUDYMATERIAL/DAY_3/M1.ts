console.log("WELCOME TO M1");
export function Adder(x: number, y: number): number
{
    console.log("M1 adder");
    return (x + y);
}

export function Adder1(x: number, y: number): number
{
    console.log("M1 adder1");
    return (x + y);
}

