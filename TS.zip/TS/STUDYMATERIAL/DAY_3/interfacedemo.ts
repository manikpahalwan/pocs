interface MyInterface
{
    //one or more abstract methods
    SayHello(): void;
    SayWelcome(): string;
}

//a class can implement the interface
//provide implementation of the methods
class MyClass implements MyInterface
{
    SayHello(): void
    {
        console.log("HELLO");
    }
    SayWelcome(): string 
    {
        return "Welcome";    
    }
}