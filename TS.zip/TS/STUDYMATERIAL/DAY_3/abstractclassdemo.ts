abstract class Vehicle
{
    public abstract Drive(): void;      //abstract method
    
    //abstract class can have non-abstract/concrete methods
    public IncreaseSpeed()
    {
        console.log("Vehicles can increase speed");
    }
}

class TwoWheeler extends Vehicle
{
    public Drive(): void
    {
        console.log("All two wheelers can be driven");
    }
}

class FourWheeler extends Vehicle
{
    public Drive(): void
    {
        console.log("All four wheelers can be driven");
    }
}

let tw: TwoWheeler = new TwoWheeler();
//tw.Drive();
//tw.IncreaseSpeed();

let fw: FourWheeler = new FourWheeler();
//fw.Drive();
//fw.IncreaseSpeed();

DriveAVehicle(tw);
DriveAVehicle(fw);


//create a polymorphic method which can call Drive() of any Vehicle
function DriveAVehicle(v: Vehicle)
{
    v.Drive();
}
