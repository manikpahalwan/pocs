setInterval(() => {
   console.log("Hello MANIK"); 
}, 4000);

for (let index = 0; index < 10000000; index++) {
    console.log("Hello");
    
}