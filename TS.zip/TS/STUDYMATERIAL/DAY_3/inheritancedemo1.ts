//super class
class Box
{
    protected width: number;
    protected height: number;
    protected depth: number;

    constructor(w: number, h: number, d: number)
    {
        this.width = w;
        this.height = h;
        this.depth = d;
        console.log("Box constr called");
    }
    public Volume(): void
    {
        console.log(`Volume is ${this.width*this.height*this.depth}`);
    }
    public PrintDetails(): void
    {
        console.log(`Width: ${this.width}`);
        console.log(`Height: ${this.height}`);
        console.log(`Depth: ${this.depth}`);
    }
}

//sub class
class BoxWeight extends Box
{
    private weight: number;

    constructor(w: number, h: number, d: number, wh: number)
    {
        //give a call to super()
        super(w, h, d);
        this.weight = wh;
        console.log("BoxWeight constr called");
    }
    public PrintDetails(): void
    {
        super.PrintDetails(); 
        console.log(`Weight is ${this.weight}`);
    }
}

let bw: BoxWeight = new BoxWeight(10, 20, 30, 600);
bw.Volume();

bw.PrintDetails();      //which PrintDetails() will be called?