class Account
{
    //define data members
    // public custid: number;
    // custname: string;       //by default public
    // private balance: number;

    //another way of defining data members
    //these data members are known as "INSTANCE MEMBERS"
    public static ifsc: string = "ICIC0000";        //static
    private static id: number = 0;  //static
    public custid: number;  //instance
    //OR
    //private static ifsc: string = "ICIC0000";


    constructor(
                //public custid: number=0, 
                public custname: string = "NA", 
                private balance: number=0.00,
            )
            {                
                //you may put code here to run when an object is created
                console.log("Account constr called");
                console.log("IFSC code is: " +Account.ifsc);
                ++Account.id;
                this.custid = Account.id;
            }

            //INSTANCE METHODS
            public Deposit(amt: number): void
            {
                //update the balance
                this.balance += amt;
                console.log("Deposited amount: " +amt);
            }
            public Withdraw(amt: number): void
            {
                //update the balance
                this.balance -= amt;
                console.log("Withdrawn amount: " +amt);
            }
            public GetBalance(): number
            {
                //some logic to authenticate/authorize the user can be done here
                //or any kind of validation logic can be put here
                return this.balance;
            }

            public static GetLastGeneratedId(): string
            {
                return Account.FormatId();
            }

            //a private static method
            //a kind of a utility function
            private static FormatId(): string
            {
                return "The last generated customer id is: " +Account.id;
            }
}

//public static members can be accessed directly using class name
//can be accessed before any objects are created
//console.log("IFSC Code: " +Account.ifsc);

//create objects
let acc1: Account = new Account("KARTHIK", 50000.00);
let acc2: Account = new Account("MANOJ", 5000000.00);
let acc3: Account = new Account();
let acc4: Account = new Account();
let acc5: Account = new Account();

console.log(acc1);
console.log(acc2);
console.log(acc3);
console.log(acc4);
console.log(acc5);

console.log(Account.GetLastGeneratedId());

let acc6: Account = new Account();
let acc7: Account = new Account();
console.log(Account.GetLastGeneratedId());

// //invoke methods
// acc1.Deposit(10000);
// console.log(acc1.GetBalance());
// acc1.Withdraw(5000);
// console.log(acc1.GetBalance());

// //access public data members using an object instance
// acc1.custname = "ABC";
// console.log(acc1)

//acc1.balance = 90000;   //ERROR since balance is private


