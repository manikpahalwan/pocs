class Circle
{
    private radius: number;      //instance member
    constructor(usersuppliedradius: number)
    {
        this.radius = usersuppliedradius;
    }
    public CalculateArea(): void
    {
        console.log("Area is: " +(3.14*this.radius * this.radius));
    }
    // public GetRadius(): number
    // {
    //     return this.radius;
    // }
    // public ChangeRadius(r: number): void
    // {
    //     this.radius = r;
    // }

    //create properties to access radius
    public get CircleRadius()           //getter/accessor method
    {
        //write some validation logic
        return this.radius;
    }
    public set CircleRadius(r: number)      //setter/mutator method
    {
        //write some validation logic
        this.radius = r;
    }
}

let c1: Circle = new Circle(5.34);
//console.log("Radius of circle c1 is: " +c1.GetRadius());
//access the radius using a property
console.log("Radius of circle c1 is: " +c1.CircleRadius);
c1.CalculateArea();

//how to change the radius of c1 object??
//c1.ChangeRadius(9.00);
//change the radius using a property
c1.CircleRadius = 9.5;
//console.log("Radius of circle c1 after change is: " +c1.GetRadius());
console.log("Radius of circle c1 is: " +c1.CircleRadius);
c1.CalculateArea();