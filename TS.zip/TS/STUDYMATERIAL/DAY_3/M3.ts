export function Adder(a: number, b: number): number
{
    //console.log("M3 adder");
    return (a + b);
}