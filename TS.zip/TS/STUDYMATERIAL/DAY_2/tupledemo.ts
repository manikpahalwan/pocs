//create a tuple
let mytuple: [number, string, boolean];
mytuple = [0, "", true];

//let mytuple: [number, string] = ["TEN", 10];    //ERROR
//individual values can be indexed just like an array
//console.log(mytuple[0]);        //10
//console.log(mytuple[1]);        //TEN

//console.log(mytuple[2]);    //ERROR

//values of a tuple can change
mytuple[0] = 1000;      //OK
console.log(mytuple);
