function SayHello(name: string = "KARTHIK"): string
{
    return "Hello: " +name;
}

let result = SayHello("MANOJ");
console.log(result);        //Hello MANOJ

result = SayHello();    
console.log(result);    //Hello KARTHIK
