type somefunction = () => string;

function GetData(): somefunction
{
    return GetDataFromServer;
}

function GetDataFromServer()
{
    return "DATA FROM SERVER";
}

let returnedfunction = GetData();   //get a function
//OR
let data = GetData()(); //get a string
console.log(GetData()());

console.log(returnedfunction());

