function DrawPolygon(...points: number[]): void
{
    console.log("Number of points: " +points.length);
}

DrawPolygon();  //length 0
DrawPolygon(1, 100, 20);    //length 3
DrawPolygon(100, 200, 300, 500, 700); //length 5
DrawPolygon(10, 20, 30);