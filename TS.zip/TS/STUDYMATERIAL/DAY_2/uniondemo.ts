//this function may return a number OR a string
type alphanumeric = number | string;

type int = number;

function FindEmployee(empid: number): alphanumeric
{
    //some logic to return either a number or  a string
    if(10 > 20)
    {
        return "KARTHIK";
    }
    return 50000;
}

let answer = FindEmployee(2153);

let n1: int = 20;
