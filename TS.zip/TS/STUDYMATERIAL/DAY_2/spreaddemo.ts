function Sum(a: number, b: number, c: number): number
{
    return (a + b + c);
}

let ans: number = Sum(10, 20, 30);
console.log(ans);

//create an array
let myarray: number[] = [10, 20, 30];
//ans = Sum(...myarray);