let x = 20;    //automatic type inference
let y: boolean = true;  //type annotation
let k;  //implicit any

k = 20;
//k ='abc'

//runtime error
//console.log(k.toUpperCase());     //OK no compilation error

k = "HELLO";        //OK




