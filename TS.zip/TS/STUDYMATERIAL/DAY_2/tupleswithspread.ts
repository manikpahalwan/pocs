function Add(a: number, b: number, c: number): number
{
    return (a + b + c);
}

//define this as a tuple
let myarray1: [number, number, number] = [10, 20, 30];
//let myarray1: number[] = [10, 20, 30];

let result1 = Add(...myarray1);
console.log(`Result of addition is ${result1}`);

myarray1[0] = 10000;
result1 = Add(...myarray1);
console.log(`Result of addition is ${result1}`);
