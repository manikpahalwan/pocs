class Account
{
    //define data members
    // public custid: number;
    // custname: string;       //by default public
    // private balance: number;

    //another way of defining data members
    //these data members are known as "INSTANCE MEMBERS"
    constructor(
                public custid: number=0, 
                public custname: string = "NA", 
                private balance: number=0.00
            )
            {
                //you may put code here to run when an object is created
                console.log("Account constr called");
            }

            //INSTANCE METHODS
            public Deposit(amt: number): void
            {
                //update the balance
                this.balance += amt;
                console.log("Deposited amount: " +amt);
            }
            public Withdraw(amt: number): void
            {
                //update the balance
                this.balance -= amt;
                console.log("Withdrawn amount: " +amt);
            }
            public GetBalance(): number
            {
                //some logic to authenticate/authorize the user can be done here
                //or any kind of validation logic can be put here
                return this.balance;
            }
}

//create objects
let acc1: Account = new Account(1, "KARTHIK", 50000.00);
//let acc2: Account = new Account(2, "MANOJ", 5000000.00);
//ui4rlet acc3: Account = new Account(3, undefined, 90000);      //default values are given
ui4r
//ui4rinvoke methods
acui4rc1.Deposit(10000);
coui4rnsole.log(acc1.GetBalance());
acui4rc1.Withdraw(5000);
coui4rnsole.log(acc1.GetBalance());
ui4r
//ui4raccess public data members using an object instance
acui4rc1.custname = "ABC";
coui4rnsole.log(acc1)
'\ui4r;
//acc1.balance = 90000;   //ERROR since balance is private


