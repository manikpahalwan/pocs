//1.	Write a standard JS function which takes a number as an argument and returns its factorial
var res = 1;
var num = 5;
function fact(num) {
    for (var i = 1; i < num + 1; i++) {
        res = res * i; // logic of factorial
    }
    return res;
}
//   function getTime(): number {
//     return new Date().getTime();
//   }
console.log(fact(num));
