let sum = (num1 : number,num2 : number )=>{
    return num1+num2;
}

// let addition : number  =sum(3,4);
console.log(sum(3,4));
//console.log(addition)