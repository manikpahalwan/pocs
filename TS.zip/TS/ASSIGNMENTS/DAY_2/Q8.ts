// 8.	Write a JS function which returns the sum of any number of arguments passed. 
// If no arguments are passed, the function must return a zero.


function sum1(...arg: number[]) {
    let sum: number = 0;
    console.log(`Number of argument is ${arg.length}`);
    console.log(`Argument = ${arg}`);
    for (let a of arg) {
        sum = sum + a;
    }
    return sum;
}

console.log(`Sum of Argument is ${sum1(12, 23, 56, 90, 12)}`);       /* When argument is passed */
console.log(`Sum of Argument is ${sum1()}`);                     /* When no arguments are passed=>returns zero */