// 4.	Write a JS arrow function named Login() which takes a username and password.
//  In case any of the arguments or both are not passed, the default values must be CT and CT respectively. 
var login = function (userName, password) {
    if (userName == "" || password == "") {
        userName = "CT";
        password = "CT";
    }
    console.log(userName);
    console.log(password);
};
login("myUserNAme", "myPassword");
login("", "");
