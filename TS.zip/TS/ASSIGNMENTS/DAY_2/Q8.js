// 8.	Write a JS function which returns the sum of any number of arguments passed. 
// If no arguments are passed, the function must return a zero.
function sum1() {
    var arg = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        arg[_i] = arguments[_i];
    }
    var sum = 0;
    console.log("Number of argument is ".concat(arg.length));
    console.log("Argument = ".concat(arg));
    for (var _a = 0, arg_1 = arg; _a < arg_1.length; _a++) {
        var a = arg_1[_a];
        sum = sum + a;
    }
    return sum;
}
console.log("Sum of Argument is ".concat(sum1(12, 23, 56, 90, 12))); /* When argument is passed */
console.log("Sum of Argument is ".concat(sum1())); /* When no arguments are passed=>returns zero */
