//9.	Write a JS function which takes 3 arguments, namely arg1, arg2 and arg3. 
//Call the function by passing an array of 3 elements to it.
// The function must return the maximum value from the array passed to it.

function maxEle(arg1: number, arg2: number, arg3: number) {
    if (arg1 < arg2) {
        if (arg2 < arg3) {
            return arg3;
        } else {
            return arg2;
        }
    } else {
        if (arg1 < arg3) {
            return arg3;
        } else {
            return arg1;
        }
    }
}

let array4: [number, number, number] = [13, 45, 100];

console.log(`Maximum number is ${maxEle(...array4)}`);

