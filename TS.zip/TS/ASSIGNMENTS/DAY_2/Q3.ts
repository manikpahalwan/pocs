//3.	Write a standard JS function which takes variable number of arguments and
// prints each argument on the screen and also the number of arguments passed.

function assignment3(...args : number[]){

    console.log(`Number of arguments passed is ${args.length}`)
    console.log(`Arguments are :`)
    for(let p  of args){
        console.log(p);
    }
}
assignment3(12,23,76,5,4)