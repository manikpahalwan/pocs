var sum = function (num1, num2) {
    return num1 + num2;
};
// let addition : number  =sum(3,4);
console.log(sum(3, 4));
//console.log(addition)
