//1.	Write a standard JS function which takes a number as an argument and returns its factorial

let res:number=1;
let num:number=5;
 

function fact(num:number):number {                            // creating function
   for (let i:number = 1; i < num+1; i++) {
        res=res*i;                              // logic of factorial
        
       }
       return res ;
  }

//   function getTime(): number {
//     return new Date().getTime();
//   }
  console.log(fact(num));