//3.	Write a standard JS function which takes variable number of arguments and
// prints each argument on the screen and also the number of arguments passed.
function assignment3() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
    }
    console.log("Number of arguments passed is ".concat(args.length));
    console.log("Arguments are :");
    for (var _a = 0, args_1 = args; _a < args_1.length; _a++) {
        var p = args_1[_a];
        console.log(p);
    }
}
assignment3(12, 23, 76, 5, 4);
