"use strict";
//10.	Write JS code to determine how many digits are repeated in the number 7312140905.
let STR_3 = "7312140905";
let Arr__1 = [];
let Arr__2 = []; //creating an arraylet Arr_2=[];
let count = 0;
for (let index = 0; index < STR.length; index++) { //storing string in array
    Arr_1.push(str[index]);
}
Arr_1.reverse;
//creating an empty string of size Arr_1 / str
for (let index = 0; index < str.length; index++) {
    Arr__2.push(0);
}
// checking for repeated digits in number
for (let i = 0; i < str.length; i++) {
    for (let j = 0; j < str.length; j++) {
        if (j == Arr__1[i]) {
            Arr__2[j] = Arr_2[j] + 1;
        }
    }
}
for (let i = 0; i < str.length; i++) {
    if (Arr__2[i] > 1) {
        count = count + 1;
    }
}
console.log("There are " + count + " digits repeated in the number " + str);
