"use strict";
//.	Write JS code to sort the array created in assignment 4 in a reverse order.
let arr_2 = [1, 2, 4, 5, 2, 7, 8, 5, 4, 9]; //creating an array 
let temp_2;
for (let i = 0; i < arr_2.length; i++) {
    for (let j = i + 1; j < arr_2.length; j++) {
        if (arr_2[i] < arr_2[j]) {
            temp_2 = arr_2[i];
            arr_2[i] = arr_2[j];
            arr_2[j] = temp_2;
        }
    }
}
console.log(arr_2);
