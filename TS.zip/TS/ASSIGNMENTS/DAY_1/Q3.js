"use strict";
//3.	Write JS code to reverse a string. Store the string in a variable.
let str = "KINAM";
console.log(typeof (str));
let new_str = "";
for (let i = str.length - 1; i >= 0; i--) {
    new_str += str[i];
}
console.log(new_str);
