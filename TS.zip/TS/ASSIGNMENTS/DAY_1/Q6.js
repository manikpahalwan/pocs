"use strict";
//6.	Write JS code to find the sum of all even numbers in an array of 10 numbers.
// In case there are no even numbers, log a message to the browser console saying No even numbers found.
let arr_3 = [1, 2, 4, 5, 2, 7, 8, 5, 4, 9]; //creating an array 
let num_3;
let y_3;
let sum = 0;
for (let i = 0; i <= arr_3.length; i++) {
    if (arr_3[i] % 2 == 0) {
        sum = sum + arr_3[i];
    }
}
if (sum > 0) {
    console.log(sum);
}
else {
    console.log("NO EVEN NUMBER FOUND");
}
