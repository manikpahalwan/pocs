"use strict";
//4.	Write JS code to create an array of 10 numbers. Find the first two maximum numbers in the array
let arr_1 = [1, 2, 4, 5, 2, 7, 8, 5, 4, 9]; //creating an array 
let num_1;
let y;
let temp;
for (let i = 0; i < arr_1.length; i++) {
    for (let j = i + 1; j < arr_1.length; j++) {
        if (arr_1[i] < arr_1[j]) {
            temp = arr_1[i];
            arr_1[i] = arr_1[j];
            arr_1[j] = temp;
        }
    }
}
console.log(arr_1[0] + " is the highest number in the array ");
console.log(arr_1[1] + " is the 2nd highest number in the array ");
