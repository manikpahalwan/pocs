//3.	Write JS code to reverse a string. Store the string in a variable.

let str:string="KINAM"
console.log(typeof(str));
let new_str:string="";
for (let i:number = str.length - 1; i >= 0; i--) {
    new_str += str[i];
}
console.log(new_str);