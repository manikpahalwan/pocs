let count:number=0;
for (let i:number=5;i <= 50;i++) 
{
    for (let j:number=2;j<i;j++)
    {
        count=0
        if(i%j==0)  //checking for prime no
            { 
            count=1;
            break;
            }
    }
    if(count==0) 
    {
        console.log(i);
    }
}
