"use strict";
let num = 123456;
// declaring and assigning value to a self assumed number
let rev = 0; // declaring variable which stores reverse of number
let lastDigit;
while (num != 0) {
    lastDigit = num % 10;
    rev = rev * 10 + lastDigit;
    num = Math.floor(num / 10); //rounding off the number
}
console.log(rev);
