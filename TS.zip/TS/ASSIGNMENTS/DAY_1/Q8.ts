//8.	Write JS code to find the number of vowels in the string CITIUSTECH.
// If the vowel is repeated, it must be counted as 1.
//let STR =prompt("ENTER THE STRING ",""); // we can take input from user too
let STR:string= "CITIUSTECH"
// vowels
let count_a:number=0;  
let count_e:number=0;
let count_i:number=0;
let count_o:number=0;
let count_u:number=0;

for (let index:number = 0; index < STR.length; index++) 
{
    if(count_a<1)                                       // checking whether a,A has presence more than once
    {
               if (STR[index]=="a" || STR[index]=="A")   // checking for presence of a,A
        {
                    count_a=count_a+1;
        }
}

if(count_e<1)                                           // checking whether e,E has presence more than once
{
           if (STR[index]=="e" || STR[index]=="E")      // checking for presence of e,E
    {
                count_e=count_e+1;
    }
}

if(count_i<1)                                           // checking whether i,I has presence more than once
{
           if (STR[index]=="i" || STR[index]=="I")      // checking for presence of i,I
    {
                count_i=count_i+1;
                
    }
}

if(count_o<1)                                           // checking whether o,O has presence more than once
{
           if (STR[index]=="o" || STR[index]=="O")      // checking for presence of o,O
    {
                count_o=count_o+1;
                
    }
}
if(count_u<1)                                           // checking whether u,U has presence more than once
{
           if (STR[index]=="u" || STR[index]=="U")      // checking for presence of u,U
    {
                count_u=count_u+1;
                
    }
}
       
}
let count__:number;
count__=count_a+count_e+count_i+count_o+count_u;
console.log("THERE ARE " + count__ +" VOVELS IN "+STR);