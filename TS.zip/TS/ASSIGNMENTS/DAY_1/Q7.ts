//7.	Write JS code to find the factorial of each number inside an array of 5 elements.
//The factorial of each number must then be stored in another array of the same size. Print the result array on the console.

let arr_4:number[]=[1,2,4,5,2,7,8,5,4,9]//creating an array 
let num_4;
let arr_5:number[]=[];

for(let i:number=0;i<arr_4.length;i++)
{
    let fact:number=1;
    for(let j:number=1;j<=arr_4[i];j++)
    {
        fact=fact*j
    }
    arr_5.push(fact);
}
console.log(arr_5);