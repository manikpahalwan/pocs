"use strict";
//9.Write JS code to create an array of 5 strings.
// Convert the last character of each string to uppercase and store the output in the same array. 
//Print the final array.
let Arr_1 = ["manik", "pahalwan"]; //creating an array
let temp_;
let len;
for (let i = 0; i < Arr_1.length; i++) {
    var temp_25 = "";
    temp_25 = Arr_1[i];
    temp_25 = temp_25.slice(0, temp_25.length - 1) + temp_25.charAt(temp_25.length - 1).toUpperCase(); //concating the last upper case letter with remaining string 
    Arr_1[i] = temp_25;
}
console.log(Arr_1);
