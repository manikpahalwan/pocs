// 4) Create an array of type any. 
// Add few numbers, strings and booleans to this array. Display the array members. 
var arr_2 = ["MANIK", "CITIUSTECH", 25, true, false];
for (var index = 0; index < arr_2.length; index++) {
    console.log("".concat(index, " --> ").concat(arr_2[index]));
}
