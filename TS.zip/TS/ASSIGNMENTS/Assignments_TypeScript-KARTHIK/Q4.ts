// 4) Create an array of type any. 
// Add few numbers, strings and booleans to this array. Display the array members. 

let arr_2:any[]=["MANIK","CITIUSTECH",25,true,false];

for (let index:number = 0; index < arr_2.length; index++) {
    console.log(`${index} --> ${arr_2[index]}`);
    
}
