// 2) Create a CustomerOperations class. Create an array of customers in CustomerOperations class.
//   Add following functions to CustomerOperations class:
// 	a) Function to add a customer to an array
// 	b) Function to retrieve all the customers from an array
//     Execute the above functions and display the output.
var CustomerOperations = /** @class */ (function () {
    function CustomerOperations(customer) {
        this.customer = customer;
    }
    CustomerOperations.prototype.addCust = function (custName) {
        this.customer.push(custName);
        console.log("".concat(custName, " added to Customer Array"));
    };
    CustomerOperations.prototype.display = function () {
        return this.customer;
    };
    return CustomerOperations;
}());
var arr = ["MANIK", "PAHALWAN"];
var CO = new CustomerOperations(arr);
CO.addCust("CITIUSTECH");
console.log(CO.display());
