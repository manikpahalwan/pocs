// 1) Create a Customer class. Add following members to it:
// 	a) customerId (numeric)
// 	b) firstName (alphabetic)
// 	c) lastName (alphabetic)
// 	d) contactNo (numeric)
// 	e) email (alphanumeric)
// 	f) isPrevilaged (boolean)

type alphanumeric = number|string ;
class Customer{
    protected customerId:number;
    protected firstName:string;
    protected lastName:string;
    protected contactNo:number;
    protected email:alphanumeric;
    protected isPrevilaged:boolean;
    
    constructor(cId:number,fName:string,lName:string,phone:number,mail:alphanumeric,
       privileged:boolean ){
        this.customerId=cId;
        this.firstName=fName;
        this.lastName=lName;
        this.contactNo=phone;
        this.email=mail;
        this.isPrevilaged=privileged;

       }
}
var i:number=1;
var i:number;
for (let index = 1; index <= 3; index++) {
    console.log(index);
    for (let index = 1; index < 3; index++) {
        console.log(index);       
    }
}

