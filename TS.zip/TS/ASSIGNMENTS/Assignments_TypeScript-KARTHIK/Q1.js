// 1) Create a Customer class. Add following members to it:
// 	a) customerId (numeric)
// 	b) firstName (alphabetic)
// 	c) lastName (alphabetic)
// 	d) contactNo (numeric)
// 	e) email (alphanumeric)
// 	f) isPrevilaged (boolean)
var Customer = /** @class */ (function () {
    function Customer(cId, fName, lName, phone, mail, privileged) {
        this.customerId = cId;
        this.firstName = fName;
        this.lastName = lName;
        this.contactNo = phone;
        this.email = mail;
        this.isPrevilaged = privileged;
    }
    return Customer;
}());
var i = 1;
for (var index = 1; index <= 3; index++) {
    console.log(index);
    for (var index_1 = 1; index_1 < 3; index_1++) {
        console.log(index_1);
        1;
    }
}
