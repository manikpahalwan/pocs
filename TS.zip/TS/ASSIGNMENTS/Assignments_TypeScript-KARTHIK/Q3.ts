// 3) Create a Tuple named contactDetails. This tuple should contain contactNo and emailId.
// Create a variable of type contactDetails, assign values to contactNo and emailId and display those values.

// type eMail=string|number
// let contactDetails:[number,eMail];

// let Contact:contactDetails;

