// 5) Create an Enum as follows:
// enum PrintMedia {
//     Newspaper = 1,
//     Newsletter,
//     Magazine,
//     Book
// }

// Write a function which accepts a parameter of type String and return the value of type PrintMedia. 
// E.g. – If ReadersDigest is passed as a parameter to the function, then function should return Magazine.
