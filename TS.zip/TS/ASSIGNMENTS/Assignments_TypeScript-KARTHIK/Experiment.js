setInterval(() => {
   console.log("Hello MANIK"); 
}, 4000);

for (let index = 0; index < 100000; index++) {
    console.log("Hello");
    
}