// function identity(arg: any): any {
//     return arg;
//   }

  function identity<Type>(arg: Type): Type {
    return arg;
  }
//   console.log(typeof 'MANIK')