// 2) Create a CustomerOperations class. Create an array of customers in CustomerOperations class.
//   Add following functions to CustomerOperations class:
// 	a) Function to add a customer to an array
// 	b) Function to retrieve all the customers from an array
//     Execute the above functions and display the output.
class CustomerOperations{
    protected customer:string[];
    
    constructor(customer:string[] ){
        this.customer=customer;
       }

    public addCust(custName:string):void{
        this.customer.push(custName);
        console.log(`${custName} added to Customer Array`)
    }
    public display():string[]{
        return this.customer
    }
    
}

let arr=["MANIK","PAHALWAN"]
let CO:CustomerOperations=new CustomerOperations(arr)

CO.addCust("CITIUSTECH")
console.log(CO.display());