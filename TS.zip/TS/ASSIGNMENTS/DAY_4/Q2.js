// 2.	Write a JS function which accepts an array of 10 numbers. 
// The function must return another array which contains only the odd numbers in the source array
var source = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
var con;
var oldArr = source; // creating copy of source
function ODD(arr) {
    var new_arr = [];
    for (var i = 0; i < arr.length; i++) {
        if (arr[i] % 2 != 0) //checking for odd numbers
         {
            new_arr.push(arr[i]); //pushing odd numbers in new_arr
        }
    }
    return new_arr;
}
source = ODD(source); //saving odd numbers in the source array
//document.write(source);
console.log("INPUT-> " + oldArr);
console.log("ODD NOs--> " + source);
