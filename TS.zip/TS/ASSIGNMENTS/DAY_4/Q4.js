// 4.Consider the following scenario:
// There are 3 functions, namely, GetVideo(), AddIntro() and AddSummary(). 
// Each method returns a Promise. The Promise when resolved must return a string after 3 seconds like this:
// 	GetVideo()	 returns Got Video
// 	AddIntro()	 returns Intro Added
// 	AddSummary()  returns Summary Added
// Invoke the GetVideo() function. The final result must be displayed as:
// 	Got Video, Intro Added, Summary Added
// function getTime(): number {
//     return new Date().getTime();
//   }
function GetVideo() {
    return new Promise(function (res, rej) {
        setTimeout(function () {
            var a = 1;
            if (a == 1) { //promise condition
                res("Got Video");
                AddIntro().then(function (x) {
                    console.log(x);
                })["catch"](function (y) {
                    console.log(y);
                });
            }
            else {
                rej("Didn't got any Vidoe");
            }
        }, 3000); //3 second timeout
    });
}
function AddIntro() {
    return new Promise(function (res, rej) {
        setTimeout(function () {
            var a = 1;
            if (a == 1) { //promise condition
                res("Intro Added");
                AddSummary().then(function (x) {
                    console.log(x);
                })["catch"](function (y) {
                    console.log(y);
                });
            }
            else {
                rej("Intro not added");
            }
        }, 3000); //3 second timeout
    });
}
function AddSummary() {
    return new Promise(function (res, rej) {
        setTimeout(function () {
            var a = 1;
            if (a == 1) { //promise condition
                res("Summary Added");
            }
            else {
                rej("No Summary Added");
            }
        }, 3000); //3 second timeout
    });
}
GetVideo().then(function (x) {
    console.log(x);
})["catch"](function (y) {
    console.log(y);
});
