//3.Refactor the JS function created in assignment 2 so that the user can pass the filter 
//condition also to the function. For example, only even numbers, only prime numbers, etc.
// The condition must NOT be passed as a string.

let source_2:number[] = [1,2,3,4,5,6,7,8,9,10];
let con_2,res;

console.log(source_2);
con = prompt("1->EVEN 2->ODD 3->PRIME ", "");              // asking user what it wants
//con=parseInt(con); 

function filter(arr, check) {                               // creating filter function
    for(val of arr){
        if(check(val)) console.log(val);
    }}

    function isOdd(val) {                                   //odd function
        return val % 2 == 1;                                //checking odd numbers
    } 
    function isEven(val) {                                  //even numbers
        return val % 2 == 0;                                //checking even numbers
    }

    function isPrime(val) {                                 //prime numbers function
    count=0;            
    for (let i = 2; i < val; i++) {
        if (val%i==0) {         
            count=count+1;  
        }
        }
        if(count==0){                                       //checking for prime number
            return val;
        }}

//checking the condition

if (con==2) {
    res=filter(source,isOdd );
}
else if(con==1){
    res=filter(source,isEven );
}
else if(con==3){
    res=filter(source,isPrime );
}

