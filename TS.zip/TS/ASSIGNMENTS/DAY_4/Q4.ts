// 4.Consider the following scenario:
// There are 3 functions, namely, GetVideo(), AddIntro() and AddSummary(). 
// Each method returns a Promise. The Promise when resolved must return a string after 3 seconds like this:
// 	GetVideo()	 returns Got Video
// 	AddIntro()	 returns Intro Added
// 	AddSummary()  returns Summary Added

// Invoke the GetVideo() function. The final result must be displayed as:
// 	Got Video, Intro Added, Summary Added


// function getTime(): number {
//     return new Date().getTime();
//   }
function GetVideo():Promise<string>  {                       //creating getVideo function
    return new Promise(function(res,rej){   //promise
        setTimeout(()=>{
            let a:number=1;                    
            if(a==1){                       //promise condition
                res("Got Video");
                AddIntro().then((x)=>{      //invoking AddIntro
                    console.log(x);}).catch((y)=>{
                    console.log(y);})
            }
            else{
                rej("Didn't got any Vidoe");
            }
           },3000)                              //3 second timeout
        })

}

function AddIntro():Promise<string> {                           //creating Add intro
    return new Promise(function(res,rej){       //promise
        setTimeout(()=>{
            let a:number=1;
            if(a==1){                           //promise condition
                res("Intro Added");
                AddSummary().then((x)=>{        //invoking AddSumary function
                    console.log(x);}).catch((y)=>{
                    console.log(y);})
            }
            else{
                rej("Intro not added");
            }
           },3000)                              //3 second timeout
        })

    
}
function AddSummary():Promise<string> {                         //creating AddSummary
    return new Promise(function(res,rej){       //promise
        setTimeout(()=>{
            let a:number=1;    
            if(a==1){                           //promise condition
                res("Summary Added");
            }
            else{
                rej("No Summary Added");
            }
           },3000)                             //3 second timeout
        })

    
}
GetVideo().then((x)=>{                          //invoking GetVideo
console.log(x);}).catch((y)=>{
console.log(y);})
